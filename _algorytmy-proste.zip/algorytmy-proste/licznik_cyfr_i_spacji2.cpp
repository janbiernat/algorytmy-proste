#include <iostream> 
#include <conio.h> 
/*--== Licznik cyfr i spacji 2 ==-- 
  Copyright (c)by Jan T. Biernat 
  == 
  Tre�� zadania: 
  Napisz program, kt�ry pobiera od u�ytkownika tekst. 
  Nast�pnie zlicza ilo�� cyfr i spacji w podanej linii. 
  Na koniec, wy�wietla nast�puj�ce informacje: 
    1) Ilo�� znak�w w linii. 
    2) Ilo�� cyfr. 
    3) Ilo�� spacji. 
*/ 
using namespace std; 
long int ZnakiIloscSpacji(string Str="") { 
  //ZnakiIloscSpacji - Funkcja podaje ilo�� spacji (tzw. znak�w pustych) wyst�puj�cych w podanym tek�cie. 
    long int Licznik = 0; 
    if(Str != "") { 
      for(int I = 0; I < Str.length(); I++) { 
        if(Str[I] == ' ') { Licznik++; } 
      } 
    } 
    return Licznik; 
} 
long int ZnakiIloscCyfr(string Str="") { 
  //ZnakiIloscCyfr - Funkcja podaje ilo�� cyfr wyst�puj�cych w podanym tek�cie. 
    string Cyfry = ""; 
    if(Str != "") { 
      for(int I = 0; I < Str.length(); I++) { 
        if(((int)Str[I] > 47) && ((int)Str[I] < 58)) { Cyfry += Str[I]; } 
      } 
      return Cyfry.length(); 
    } else { return 0; } 
} 
//Blok g��wny/startowy. 
int main () { 
  cout << "--== Licznik cyfr i spacji 2 ==--\n"; 
  cout << "Copyright (c)by Jan T. Biernat\n\n"; 
  //Deklaracja zmiennych. 
    string Tekst = ""; 
  //Pobranie danych z klawiatury. 
    cout << "Podaj tekst: "; 
    getline(cin, Tekst); 
  //Wykonanie zadania. 
    cout << "\nPodany tekst to: \"" << Tekst << "\"."; 
    cout << "\nIlosc znakow   : " << Tekst.length() << "."; 
    cout << "\nIlosc cyfr     : " << ZnakiIloscCyfr(Tekst) << "."; 
    cout << "\nIlosc spacji   : " << ZnakiIloscSpacji(Tekst) << "."; 
  //Czekaj, a� u�ytkownik naci�nie klawisz ENTER. 
    cout << "\n\nNacisnij klawisz ENTER..."; 
    getch(); 
} 