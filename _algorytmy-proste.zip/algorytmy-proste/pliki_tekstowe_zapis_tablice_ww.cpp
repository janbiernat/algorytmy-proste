#include <iostream> 
#include <conio.h> 
#include <cstdlib> //1 
#include <ctime>   //2 
#include <fstream> //3 
/*--== Tablice wielowymiarowe - Pliki tekstowe - Zapis ==-- 
  Copyright(c)by Jan T. Biernat*/ 
using namespace std; 
//Blok g��wny/startowy. 
int main() { 
  cout <<"--== Tablice wielowymiarowe - Pliki tekstowe - Zapis ==--\n"; 
  cout <<"Copyright(c)by Jan T. Biernat\n\n"; 
  //Deklaracja sta�ych. 
    const int IloscElementow = 7; 
    const int Zakres = 9; 
  //Deklaracja zmiennych. 
    int Tablica[IloscElementow][IloscElementow]; 
  //Wprowad� dane do tablicy. 
    srand(time(NULL)); //4 
    for(int A=0; A < IloscElementow; A++) { 
      for(int B=0; B < IloscElementow; B++) { 
        Tablica[A][B] = 0; 
        Tablica[A][B] = rand()%Zakres; 
      } 
    } 
  //Zapisz tablic� do pliku. 
    cout.width(2); //5 
    fstream PlikDane("tablice.txt", ios::out | ios::trunc); //6 
    PlikDane << "Wylosowana tablica:"; //7 
    for(int A=0; A < IloscElementow; A++) { 
      PlikDane << "\n "; //7 
      for(int B=0; B < IloscElementow; B++) { 
        if(B > 0) { PlikDane << ", "; } //7 
        PlikDane << Tablica[A][B]; //7 
      } 
    } 
    PlikDane.close(); //8 
  //Naci�nij dowolny klawisz. 
    cout << "\n\nNacisnij dowolny klawisz..."; 
    getch(); 
/* 
  Legenda: 
   1) Posiada instrukcje do zainicjowania generatora liczb pseudolosowych. 
   2) Biblioteka "ctime " zawiera funkcje zwi�zane z obs�ug� czasu i daty. 
   3) Posiada funkcje zwi�zane z obs�ug� plik�w. 
   4) Zainicjowanie generatora liczb pseudolosowych. 
   5) Przesuni�cie liczby do prawej strony na polu 2 znakowym. 
      (tzn. napisanie liczby 3, spowoduje dodanie 1 znaku pustego przed napisan� liczb�/cyfr�). 
   6) Utworzenie obiektu o nazwie "PlikDane" na podstawie klasy "fstream". 
      Od tego momentu mo�na u�ywa� instrukcji, kt�re nale�� do klasy "fstream". 
      Otwarcie pliku do zapisu (tj. ios::out) i zredukowanie rozmiaru pliku do zera 
      (tj. ios::trunc), je�eli plik wcze�niej istnia�. 
      Skr�t: trunc pochodzi do s�owa ang. truncate - skraca�, skr�ci� (dotyczy czasu). 
   7) Zapisanie pobranych danych do pliku tekstowego. 
   8) Zamkni�cie pliku. 
*/ 
} 