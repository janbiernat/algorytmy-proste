#include <iostream> /*Biblioteka "iostream" (ang. input/output stream) 
                      oznacza strumie� wej�cia/wyj�cia. 
                      Za pomoc� tej biblioteki mo�na m.in. wprowadza� 
                      informacje ze standardowych urz�dze� 
                      wej�cia (klawiatura) lub wyprowadza� 
                      informacje ze standardowych urz�dze� 
                      wyj�cia (ekran).*/ 
#include <conio.h>  //Obs�uga klawiatury za pomoc�. 
#include <windows.h> //Biblioteka posiada funkcje Windows API. 
using namespace std; 
void Literowanie(string Str="") { 
  //Literowanie - Wy�wietl tekst znak po znaku. 
    if(Str != "") { 
      for(int I = 0; I < Str.length(); I++) { 
        cout << Str[I]; 
        Sleep(200); 
      } 
    } 
} 
//Blok g��wny. 
int main() { 
  cout << "--== Literowanie ==--\n"; 
  cout << "Copyright (c)by Jan T. Biernat\n\n"; 
  //Deklaracja zmiennych. 
    string Tekst = ""; 
  //Pobierz dane z klawiatury. 
    cout << "Tekst: "; 
    getline(cin, Tekst); //Pobiera ci�g znak�w ze spacjami w �rodku i przypisuje do zmiennej tekstowej "Tekst". 
    cout << Tekst << " = "; 
    Literowanie(Tekst); 
  //Naci�nij dowolny klawisz. 
    cout << "\n\nNacisnij dowolny klawisz..."; getch(); 
} 