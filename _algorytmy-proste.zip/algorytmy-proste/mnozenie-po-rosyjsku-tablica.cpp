#include <iostream> 
#include <conio.h> 
using namespace std; 
/* 
  --== Mo�enie po rosyjsku - Tablica ==-- 
  Copyright (c)by Jan T. Biernat 
  = 
  Algorytm: 
  Krok 1 - Zapisz obok siebie 2 liczby, kt�re chcesz pomno�y� (np. 120 i 47 lub 5 i 10). 
  Krok 2 - W 1 kolumnie w kolejnych wierszach podwajaj zapisan� liczb�. 
           Natomiast w drugiej kolumnie w kolejnych wierszach dziel liczb� 
           ca�kowit� przez 2 i odrzucaj reszt� (np. 5/2 = 2.5, to odrzucaj reszt� tj. 0.5). 
  Krok 3 - Kontynuuj dzia�anie do momentu, a� w drugiej kolumnie osi�gniesz 1. 
  Krok 4 - Je�eli liczba w drugiej kolumnie jest parzysta, to wykre�l ca�y wiersz. 
  Krok 5 - Podsumuj (dodaj) wszystkie liczby z pierwszej kolumny. To jest wynik z mno�enia. 
  Na przyk�ad: 
    120 | 47 
    240 | 23 
    480 | 11 
    960 |  5 
   1920 |  2 <- ten wiersz ca�y usuwamy. 
   3840 |  1 
 Sumujemy liczby: 120+240+480+960+3840 = 5640. 
*/ 
int main() { 
  cout << "--== Mozenie po rosyjsku - Tablica ==--\n"; 
  cout << "Copyright (c)by Jan T. Biernat\n\n"; 
  //Deklaracja zmiennych. 
    int Liczby[4]; 
  //Wyzerowanie tablicy. 
    for(int I = 0; I < 4; I++) { Liczby[I] = 0; } 
  //Wy�wietlenie pytania i pobranie danych z klawiatury. 
    cout << "A = "; cin >> Liczby[0]; 
    cout << "B = "; cin >> Liczby[1]; 
  //Wy�wietlenie wyniku z mno�enia dw�ch liczb wykonanego tradycyjn� metod�. 
    Liczby[2] = Liczby[0]*Liczby[1]; 
    cout << Liczby[0] << " * " << Liczby[1] << " = " << Liczby[2]; 
  //Algorytm: Mno�enie po rosyjsku. 
    cout << "\n"; 
    for(int I = 0; Liczby[1] > 0; I++) { 
      if(Liczby[1] % 2 != 0) { Liczby[3]+= Liczby[0]; } 
      cout << "\n";
      cout.width(7); cout << Liczby[0] << " | "; 
      cout.width(7); cout << Liczby[1]; 
      Liczby[0] = 2 * Liczby[0]; 
      Liczby[1] = Liczby[1] / 2; 
    } 
    cout << "\n\nSuma = " << Liczby[3] << "\n"; 
    if(Liczby[3] == Liczby[2]) { cout << "Wyniki sa takie same!"; } 
    else { cout << "BLAD -?Wyniki s� bledne!"; } 
  //Czekaj, a� u�ytkownik naci�nie klawisz ENTER. 
    cout << "\n\n\nNacisnij klawisz ENTER..."; 
    getch(); 
} 