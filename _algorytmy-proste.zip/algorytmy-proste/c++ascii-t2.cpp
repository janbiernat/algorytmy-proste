#include <iostream> 
#include <conio.h> 
#include <cstdlib> //Biblioteka zawieraj�ca standardowe funkcje j�zyka C (w tym funkcje itoa). 
using namespace std; 
/*--== Tablica ASCII 2 ==-- 
 Copyright (c)by Jan T. Biernat 
 Borland Turbo Pascal 7 - Kurs podstawowy 
 = 
 Tablica kod�w ASCII (ang. American Standard Code for Information 
 Interchange) stanowi zestaw kod�w u�ywanych do reprezentacji znak�w 
 (liter, cyfr, znak�w specjalnych np. @, $, # itp.). 
 Ka�dy znak w tabeli ma przyporz�dkowan� warto�� liczbow� dziesi�tn�, 
 np. litera du�a "A"  ma warto�� dziesi�tn� 65. 
 Tablica ASCII sk�ada si� 255 znak�w, kt�re podzielone s� na kilka grup: 
   > Od 0 do 31 - znaki steruj�ce np. klawiszem ENTER, TAB, drukark�; 
   > Od 32 do 126 - znaki podstawowe; 
   > Od 127 do 255 - znaki dodatkowe (zawieraj� znaki graficzne, 
                     oraz znaki polskie itp.). 
 Podstawowa tabela ASCII (tj. od 0 do 127) nie podlega wymianie, 
 natomiast rozszerzona tablica (tj. od 128 do 255) mo�e ulega� zmianie 
 np. w celu zakodowania polskich znak�w. 
*/ 
int main() { 
  cout << "--== Tabela kodow ASCII 2 ==--\n"; 
  cout << "Copyright (c)by Jan T. Biernat\n\n"; 
  //Deklaracja zmiennych znakowych. 
    char Hex[32], Bin[32]; 
  //Tablica kod�w ASCII od znaku pustego (tzw. spacji). 
    for(int I = 0; I < 224; I++) { 
      cout << "\n" << char(32) << char(32+I) << char(32) << char(32); 
      if((32+I) < 100) { cout << "0" << (32+I); } else { cout << (32+I); } 
      cout << char(32) << char(32) << itoa((32+I), Hex, 16); 
      cout << char(32) << char(32) << itoa((32+I), Bin, 2); 
    } 
  //Czekaj, a� u�ytkownik naci�nie klawisz ENTER. 
    cout << "\n\nNacisnij klawisz ENTER..."; getch(); 
/* 
  itoa(P1, P2, P3) - Konwertuje liczb� ca�kowit� na �a�cuch znak�w. 
  P1 - w tym parametrze umieszczamy liczb� ca�kowit�. 
  P2 - w tym parametrze umieszczamy zmienn� typu char, kt�ra 
       b�dzie przechowywa� wynik konwersji. 
  P3 - w tym parametrze okre�lamy podstaw� systemu liczbowego w kt�rym 
       b�dzie zapisy wynik. 
*/ 
} 