#include <iostream> /*Biblioteka "iostream" (ang. input/output stream) 
                      oznacza strumie� wej�cia/wyj�cia. 
                      Za pomoc� tej biblioteki mo�na m.in. wprowadza� 
                      informacje ze standardowych urz�dze� 
                      wej�cia (klawiatura) lub wyprowadza� 
                      informacje ze standardowych urz�dze� 
                      wyj�cia (ekran).*/ 
#include <conio.h>  /*Obs�uga klawiatury za pomoc�.*/ 
/*--== Sortowanie alfabetyczne ==-- 
  Copyright(c)by Jan T. Biernat*/ 
using namespace std; 
void TablicaJW_Pokaz(string Tablica[], int IloscElementow=0) { 
  //TablicaJW_Pokaz - Wy�wietl zawarto�� tablicy podanej w 1 parametrze. 
    if(IloscElementow > 0) { 
      for(int I = 0; I < IloscElementow; I++) { 
        if(I > 0) { cout << ", "; } 
        cout << "\n" << Tablica[I]; 
      } 
      cout << "."; 
    } else { cout << "BLAD -?"; } 
} 
//Blok g��wny. 
int main() { 
  cout << "--== Sortowanie alfabetyczne ==--\n"; 
  cout << "Copyright (c)by Jan T. Biernat\n\n"; 
  //Deklaracja sta�ych. 
    const short int IloscElementow = 15; 
  //Deklaracja zmiennych. 
    string Tablica[IloscElementow]  = { 
                                        "Atari", 
                                        "Amiga", 
                                        "ZX Spectrum", 
                                        "Amstrad", 
                                        "Commodore", 
                                        "Pegasus", 
                                        "Atari Portfolio", 
                                        "Atari TT", 
                                        "Atari 65XE", 
                                        "Joystick", 
                                        "Rive Raid", 
                                        "Robbo", 
                                        "Fred", 
                                        "Misja", 
                                        "Lasermania" 
                                      }; 
    string Temp = ""; 
  //Wy�wietl zawarto�� tablicy, przed posortowaniem alfabetycznym. 
    cout << "\nZawartosc tablicy, przed posortowaniem alfabetycznym:"; 
    TablicaJW_Pokaz(Tablica, IloscElementow); //Wywo�anie funkcji "TablicaJW_Pokaz". 
    cout << "\n\n"; 
  //Sortowanie alfabetyczne. 
    for(int A = 0; A < IloscElementow; A++) { 
      for(int B = 0; B < IloscElementow; B++) { 
        if(Tablica[A] < Tablica[B]) { 
          Temp = ""; 
          Temp = Tablica[B]; 
          Tablica[B] = Tablica[A]; 
          Tablica[A] = Temp; 
        }; 
      }; 
    }; 
  //Wy�wietl zawarto�� tablicy, po posortowaniu alfabetycznym. 
    cout << "\nZawartosc tablicy, po posortowaniu alfabetycznym:"; 
    TablicaJW_Pokaz(Tablica, IloscElementow); //Wywo�anie funkcji "TablicaJW_Pokaz". 
    cout << "\n"; 
  //Naci�nij dowolny klawisz. 
    cout << "\n\nNacisnij dowolny klawisz..."; getch(); 
} 