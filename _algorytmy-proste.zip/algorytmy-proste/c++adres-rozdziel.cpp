#include <iostream> 
#include <conio.h> 
using namespace std; 
/*--== Rozdziel pe�ny adres na cz�ci - konsola ==-- 
  Copyright (c)by Jan T. Biernat 
  - 
  Zadanie: 
  Napisz program, kt�ry rozdzieli podanych adres 
  na poszczeg�lne elementy. 
  Na przyk�ad: 
    Adres pe�ny: Armii Krajowej 543/23a. 
    Poszczeg�lne cz�ci adresu: 
      1) Ul.                    : Armii Krajowej. 
      2) Nr domu i nr mieszkania: 543/23a. 
      3) Nr domu                : 543. 
      4) Nr mieszkania          : 23a. 
*/ 
int main() { 
  cout << "--== Rozdziel pelny adres na czesci - konsola ==--\n"; 
  cout << "Copyright (c)by Jan T. Biernat\n\n"; 
  //Deklaracja zmiennych. 
    string AdresPelny = ""; 
    int AdresNrSpacji = 0, AdresNrUkosnik = 0, ZnakNr = 0; 
  //Pobranie danych z klawiatury. 
    cout << "\nAdres: "; getline(cin, AdresPelny); 
    if(AdresPelny != "") { 
      cout << "\nAdres pelny                      : \"" << AdresPelny << "\"."; 
      //Znajd� znak spacji od prawej strony. 
        for(int I = AdresPelny.length(); I > -1; I--) { //1. 
          if(AdresPelny[I] == '/') { AdresNrUkosnik = I; } //2. 
          if(AdresPelny[I] == ' ') { AdresNrSpacji = I; break; } //3. 
        } 
        if(AdresNrSpacji != 0) { 
          ZnakNr = 0; ZnakNr = (int)AdresPelny[AdresNrSpacji+1]; //4. 
          if((ZnakNr > 47) && (ZnakNr < 58)) { 
            cout << "\nUlica                            : \"" << AdresPelny.substr(0, AdresNrSpacji) << "\"."; //5. 
            cout << "\nNr domu lub bloku i nr mieszkania: \"" << AdresPelny.substr(AdresNrSpacji+1, AdresPelny.length()) << "\"."; 
            if(AdresNrUkosnik > 0) { 
              cout << "\nNr domu lub bloku                : \"" << AdresPelny.substr(AdresNrSpacji+1, AdresNrUkosnik-(AdresNrSpacji+1)) << "\"."; 
              cout << "\nNr mieszkania                    : \"" << AdresPelny.substr(AdresNrUkosnik+1, AdresPelny.length()) << "\"."; 
            } 
          } 
        } 
    } else { cout << "BLAD -?Brak danych!\n"; } 
  //Zatrzymaj program do czasu naci�ni�cia klawisza. 
    cout << "\n\n\nNacisnij dowolny klawisz ..."; getch(); 
/* 
  Legenda: 
   1) P�tla FOR b�dzie tyle razy wykonana, ile jest znak�w w podanym tek�cie. 
      W tym przyk�adzie p�tla wykonana jest od ty�y (czyli od prawej do lewej). 
   2) Wykrycie za pomoc� warunku, na kt�rym nr indeksu znajduje si� znak uko�nika (tj. "/"). 
      Je�eli znak uko�nika zostanie wykryty, to nr indeksu (kt�ry przechowywany jest w zmiennej liczbowej "I") 
      zostanie przepisany do zmiennej liczbowej "AdresNrUkosnik". 
   3) Wykrycie za pomoc� warunku, na kt�rym nr indeksu znajduje si� znak spacji (tj. " "). 
      Je�eli znak spacji zostanie wykryty, to nr indeksu (kt�ry przechowywany jest w zmiennej liczbowej "I") 
      zostanie przepisany do zmiennej liczbowej "AdresNrSpacji" i nast�pi przerwanie dzia�anie p�tli. 
   4) Wyzerowanie zmiennej liczbowej "ZnakNr". 
      Nast�pnie wykonaj nast�puj�ce kroki: 
       a) Pobierz znak znajduj�cy si� na pozycji o podanym nr indeksu. 
          Nr indeksu jest przechowywany w zmiennej "AdresNrSpacji" i jest powi�kszony o dodan� warto�� liczbow� 1. 
          Plus 1 jest dlatego, �e sama zmienna liczbowa "AdresNrSpacji" przechowuje 
          tylko nr indeksu na kt�rym znajduje si� znak spacji. Natomiast pobrany musi by� znak kolejny 
          w celu wykrycia, czy jest to liczba. 
       b) Wykonaj rzutowanie pobranego znaku na typ integer. Czyli zamie� znak na jego dziesi�tny odpowiednik. 
       c) Dziesi�tny kod znaku (kt�ry jest typu integer) przepisz do zmiennej liczbowej "ZnakNr". 
   5) Wy�wietlenie na ekranie tekstu znajduj�cego pomi�dzy cudzys�owami oraz wy�wietlenie na ekranie 
      fragmentu tekstu. Fragment tekstu jest wyci�gni�ty ze zmiennej tekstowej "AdresPelny" za pomoc� 
      funkcji "substr". 
*/ 
} 