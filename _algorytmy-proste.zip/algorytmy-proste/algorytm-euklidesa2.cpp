#include <iostream> //Obs�uga strumieni (np. przesy�anie danych na ekran). 
#include <conio.h>  //Obs�uga klawiatury. 
#include <math.h>   //Biblioteka z funkcjami matematycznymi. 
using namespace std; 
/*--== Algorytm Euklidesa ==-- 
  Algorytm Euklidesa � algorytm wyznaczania najwi�kszego 
  wsp�lnego dzielnika dw�ch liczb. Zosta� opisany przez 
  greckiego matematyka, Euklidesa w jego dziele �Elementy�. 
  
  Euklides wykorzysta� prosty fakt, i� NWD liczb a i b dzieli r�wnie� ich r�nic�. 
  Zatem od wi�kszej liczby odejmujemy w p�tli mniejsz� dot�d, a� obie liczby si� zr�wnaj�. 
  Wynik to NWD dw�ch wyj�ciowych liczb. 
   
  Specyfikacja algorytmu: 
  1) Dane wej�ciowe: a, b (liczby naturalne). 
  2) Wynik: liczba naturalna, b�d�ca najwi�kszym wsp�lnym podzielnikiem 
            liczb a i b. 
  3) Zmienne pomocnicze: nie u�ywany. 
  4) Funkcje pomocnicze: nie u�ywane. 
*/ 
int main() { 
  cout << "--== Algorytm Euklidesa ==--\n"; 
  int A=0, B=0; 
  cout << "Podaj A: "; cin >> A; 
  cout << "Podaj B: "; cin >> B; 
  cout << "\nNWD("<< A << ", " << B << ") to liczba "; 
  while(A != B) { 
    if(A < B) { B = B-A; } 
    else { A = A-B; } 
  } 
  cout << A << ".\n"; 
} 