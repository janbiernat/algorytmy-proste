#include <iostream> 
#include <cstdlib> //1 
#include <conio.h> 
using namespace std; 
//Blok g��wny/startowy. 
int main() { 
  cout <<"--== Dec2Bin3 ==--\n"; 
  cout <<"Copyright (c)by Jan T. Biernat\n"; 
  cout <<"Systemy liczbowe: Dziesietny -> Dwojkowy.\n\n"; 
  //Deklaracja zmiennych. 
    long int Liczba = 0; 
    char Wynik[] = ""; 
  //Pobranie liczby od u�ytkownika. 
    cout << "Podaj liczbe dwojkowa: "; 
    cin >> Liczba; 
  //Przeliczenie liczby 10 na liczb� 2 i 16. 
    cout << "\n" << Liczba << " = "; 
    itoa(Liczba, Wynik, 2); //2 
    cout << Wynik; 
  //Czekaj, a� u�ytkownik naci�nie klawisz ENTER. 
    cout << "\n\nNacisnij klawisz ENTER..."; 
    getch(); 
/* 
  Legenda: 
    1) Biblioteka zawieraj�ca funkcje og�lne 
       (m.in. losowanie liczb, konwersji �a�cuch�w znak�w). 
    2) //itoa(p1, p2, p3) - Konwertuje podan� liczb� na okre�lony 
                            system liczbowy w postaci �a�cucha znak�w. 
                            Opis  parametr�w: 
                            p1 - nale�y poda� liczb� ca�kowit�. 
                            p2 - nale�y umie�ci� zmienn� typu "char", 
                                 w kt�rej b�dzie przechowywany wynik 
                                 w postaci odpowiedniego systemu liczbowego. 
                                 Wyb�r systemu liczbowego nast�puje w parametrze 3. 
                            p3 - umo�liwia wybranie systemu liczbowego, w kt�rym 
                                 b�dzie zapisany wynik konwersji liczby znajduj�cej 
                                 si� w pierwszym parametrze. 
*/ 
} 