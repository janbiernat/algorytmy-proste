#include <iostream> 
#include <conio.h> 
#include <cstdlib> //1. 
#include <windows.h> //2. 
using namespace std; 
/*--== Tablica ASCII w konsoli ==-- 
  Copyright (c)by Jan T. Biernat 
 = 
 Tablica kod�w ASCII (ang. American Standard Code for Information 
 Interchange) stanowi zestaw kod�w u�ywanych do reprezentacji znak�w 
 (liter, cyfr, znak�w specjalnych np. @, $, # itp.). 
 Ka�dy znak w tabeli ma przyporz�dkowan� warto�� liczbow� dziesi�tn�, 
 np. litera du�a "A"  ma warto�� dziesi�tn� 65. 
 Tablica ASCII sk�ada si� 255 znak�w, kt�re podzielone s� na kilka grup: 
   > Od 0 do 31 - znaki steruj�ce np. klawiszem ENTER, TAB, drukark�; 
   > Od 32 do 126 - znaki podstawowe; 
   > Od 127 do 255 - znaki dodatkowe (zawieraj� znaki graficzne, 
                     oraz znaki polskie itp.). 
 Podstawowa tabela ASCII (tj. od 0 do 127) nie podlega wymianie, 
 natomiast rozszerzona tablica (tj. od 128 do 255) mo�e ulega� zmianie 
 np. w celu zakodowania polskich znak�w. 
*/ 
int main() { 
  //Deklaracja sta�ych. 
    const short int WierszeIlosc = 21; 
  //Deklaracja zmiennych. 
    char Hex[32], Bin[32]; 
    int KodKlaw = 0, MenuWybrano = 0, ZnakNr = 0, ZnakNrASCII = 0; 
    HANDLE UchwytDoKonsoli; //3. 
    UchwytDoKonsoli = GetStdHandle(STD_OUTPUT_HANDLE); //4. 
  //Tablica ASCII. 
    do { 
      system("cls"); //5. 
      cout << "--== Tablica ASCII w konsoli ==--\n"; 
      cout << "Copyright (c)by Jan T. Biernat\n\n"; 
      //Tablica kod�w ASCII od znaku pustego (tzw. spacji). 
        cout << "ESC - Wyjscie z programu.\n\n"; 
        cout << "\n  Znak  Dec  Hex  Bin"; 
        for(int I = 0; I < WierszeIlosc; I++) { 
          cout << "\n  "; 
          ZnakNrASCII = 0; ZnakNrASCII = 32+I+ZnakNr; 
          if(MenuWybrano == I) { SetConsoleTextAttribute(UchwytDoKonsoli, 112); } 
          else { SetConsoleTextAttribute(UchwytDoKonsoli, 7); } //6. 
          cout << "  " << char(ZnakNrASCII) << "   "; 
          if((ZnakNrASCII) < 100) { cout << "0" << (ZnakNrASCII); } else { cout << (ZnakNrASCII); } 
          cout << "  " << itoa((ZnakNrASCII), Hex, 16) << "   "; //7. 
          cout.width(8); cout.fill('0'); //8. 
          cout << itoa((ZnakNrASCII), Bin, 2) << "  "; //7. 
          SetConsoleTextAttribute(UchwytDoKonsoli, 7); //6. 
        } 
        cout << "\n"; 
      //Obs�uga klawiszy. 
        KodKlaw = 0; 
        KodKlaw = getch(); //9. 
        if((KodKlaw == 0) || (KodKlaw == 224)) { //10. 
          KodKlaw = 0; KodKlaw = getch()+224; //11. 
        } 
          if(KodKlaw == 296) { 
            //Strza�ka w g�ra. 
              MenuWybrano--; 
              if(MenuWybrano < 0) { 
                MenuWybrano = 0; 
                ZnakNr--; 
                if(ZnakNr < 0) { ZnakNr = 0; } 
              } 
          } else if(KodKlaw == 304) { 
                   //Strza�ka w d�. 
                     MenuWybrano++; 
                     if(MenuWybrano > WierszeIlosc-1) { 
                       MenuWybrano = WierszeIlosc-1; 
                       ZnakNr++; 
                       if(ZnakNr > 256-(WierszeIlosc+32)) { ZnakNr = 256-(WierszeIlosc+32); } 
                     } 
                 } 
    } while(KodKlaw != 27); //12. 
/* 
  Legenda: 
   1) Pod��czenie biblioteki "cstdlib", kt�ra posiada m.in. funkcje: 
      * konwersji ci�gu znak�w na liczb� i odwrotnie, 
      * losuj�ce liczb� z podanego zakresu, 
      * do wywo�ywania polece� systemowych. 
      * manipulatory s�u��ce do formatowania danych wyj�ciowych za pomoc� instrukcji cout. 
   2) Pod��czenie biblioteki "windows.h" zawieraj�cej funkcje zwi�zane z WinAPI. 
   3) Zadeklarowanie zmiennej "UchwytDoKonsoli", kt�ra jest uchwytem do konsoli (tj. wiersza polece�). 
      Uchwyt ten wykorzystywany jest w funkcjach windowsowych jako parametr. 
   4) Funkcja GetStdHandle zwraca standardowy uchwyt wyj�cia do konsoli (tj. STD_OUTPUT_HANDLE) 
      i przypisuje j� do zmiennej "UchwytDoKonsoli". 
   5) Wywo�anie polecenia systemowego CLS w konsoli (tj. wierszu plecenia). 
   6) SetConsoleTextAttribute(P1, P2) - funkcja umo�liwia ustawienie koloru dla tekstu w konsoli (tj. wierszu polecenia). 
      W parametrze 1 (tj. P1) - umieszczamy uchwyt do konsoli, czyli zmienn� "UchwytDoKonsoli". 
      Natomiast w parametrze 2 (tj. P2) umieszczamy numer koloru. 
      Np:   7 - tekst jest bia�y na czarnym tle, 
          112 - tekst jest czarny na bia�ym tle, 
           63 - tekst jest bia�y na niebieskim tle. 
   7) Instrukcja itoa(P1, P2, P3) - Konwertuje liczb� ca�kowit� na �a�cuch znak�w. 
       P1 - w tym parametrze umieszczamy liczb� ca�kowit�. 
       P2 - w tym parametrze umieszczamy zmienn� typu char, kt�ra 
            b�dzie przechowywa� wynik konwersji. 
       P3 - w tym parametrze okre�lamy podstaw� systemu liczbowego w kt�rym 
            b�dzie zapisy wynik. 
   8) Instrukcja cout.width(8) wyr�wnuje liczb� do prawej strony i przeznacza na liczb� 8 miejsc. 
      Instrukcja cout.fill('0') dope�nia zerami do 8 miejsc. 
      Na przyk�ad: 123456 => 00123456. 
   9) Pobranie kodu znaku za pomoc� instrukcji "getch()" i przypisanie go do zmiennej liczbowej "KodKlaw". 
      Je�eli zostan� naci�ni�te klawisze strza�ki lub inne klawisze funkcyjne to instrukcja "getch()" zwr�ci kod 224 lub 0, 
      a dopiero p�niej kod klawisza. 
      To znaczy dla strza�ki: 
      * w g�r� kod 72, 
      * w d� kod 80, 
      * w lewo kod 75, 
      * w prawo kod 77. 
      Funkcja "getch()" zwraca kod 224 lub 0 w kompilatorach MinGW (Falcon C++) i Visual C++. 
      W innych kompilatorach kody te mog� by� inne, poniewa� nie ma okre�lonego standardu. 
  10) Sprawdzenie, czy zosta� naci�ni�ty klawisz funkcyjny, je�eli tak to odczytaj ponownie 
      kod klawisza z dodan� warto�ci� 224 (nr 11). 
  11) Odczytaj ponownie kod klawisza z dodan� warto�ci� 224 i przypisz kod znaku do zmiennej liczbowej "KodKlaw". 
  12) P�tla DO ... WHILE jest tak d�ugo wykonywana, a� u�ytkownik naci�nie klawisz ESC. 
*/ 
} 