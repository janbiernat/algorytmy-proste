#include <iostream> 
#include <conio.h> 
/*--== Argumenty wywo�ania 3 w p�tli ==-- 
  Copyright (c)by Jan T. Biernat*/ 
using namespace std; 
int main(int argc, char *argv[]) { //1 
  cout << "--== Argumenty wywolania 3 w petli ==--\n"; 
  cout << "Copyright (c)by Jan T. Biernat\n\n"; 
  //Wy�wietl zawarto�� argument�w. 
    for(int I = 0; I < argc; I++) { 
      cout << "\n" << "Argument o indeksie " << I << " zawiera: " << argv[I]; 
    } 
  //Naci�nij dowolny klawisz. 
    cout << "\n\nNacisnij dowolny klawisz..."; 
    getch(); 
/* 
  Legenda: 
    1) Parametr o standardowej nazwie ARGC okre�la ilo�� podanych argument�w 
       w czasie wywo�ania programu. Argument o numerze 0 zawsze zawiera nazw� 
       wywo�ywanego programu. 
       Zmienna ARGV jest tablic� przechowuj�c� podane argumenty 
       w trakcie wywo�ania programu. Indeksowanie w tablicy rozpoczyna 
       si� od warto�ci 0. 
*/ 
} 