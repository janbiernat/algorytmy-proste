#include <iostream> 
#include <conio.h> 
using namespace std; 
/*--== Najwi�kszy wsp�lny dzielnik (NWD) ==-- 
  Implementacja (c)by Jan T. Biernat 
  = 
  Algorytm Euklidesa s�u�y do obliczania 
  NWD (najwi�kszego wsp�lnego dzielnika) 
  dw�ch liczb ca�kowitych. 
  - 
  Euklides z Aleksandrii �  matematyk grecki 
  przez wi�kszo�� �ycia dzia�aj�cy 
  w Aleksandrii (Egipt). 
  Skracanie u�amk�w zwyk�ych - przyk�ady: 
   1) 
      6   6 : 3   2 
      - = ----- = - = NWD to 3, (poniewa� 6/9 = 2/3 = 0.66) 
      9   9 : 3   3 
 
   2) 
      21   21 : 7   3 
      -- = ------ = - = NWD to 7, (poniewa� 21/14 = 3/2 = 1.5) 
      14   14 : 7   2 
   3) NWD liczb 10 i 6 to liczba 2. 
   4) NWD liczb 75 i 100 to liczba 25. 
   5) NWD liczb 15 i 5 to liczba 5. 
*/ 
int nwd(int A = 0, int B = 0) { 
//Funkcja NWD zwraca najwi�kszy wsp�lny dzielnik podanych 2 liczb. 
  if((A > -1) && (B > -1)) { 
    while(A != B) { 
      if(A > B) { A = A - B; } 
      else { B = B - A; } 
    } 
    return A; 
  } else { return -1; } 
} 
//Blok g��wny(startowy). 
int main() { 
  cout << "--== Najwiekszy wspolny dzielnik (NWD) ==--\n"; 
  cout << "Implementacja (c)by Jan T. Biernat\n\n"; 
  //Deklaracja zmiennych. 
    int A = 0, B = 0; 
  //Wykonaj zadanie. 
    cout << "A: "; cin >> A; 
    cout << "B: "; cin >> B; 
    cout << "NWD(" << A << ", " << B << ") = " << nwd(A, B) << "\n"; 
  //Czekaj, a� u�ytkownik naci�nie dowolny klawisz. 
    cout << "\n\nNacisnij dowolny klawisz ..."; getch(); 
} 