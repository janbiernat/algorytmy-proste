#include <iostream> 
#include <conio.h> 
/*--== Szukaj wyrazu w wyrazie 2 ==-- 
  Copyright (c)by Jan T. Biernat 
  == 
  Tre�� zadania: 
  Napisz program, kt�ry pobiera od u�ytkownika dwa s�owa. 
  Nast�pnie sprawdza, czy pierwsze z podanych s��w jest cz�ci� drugiego s�owa. 
  Je�li tak, to z tego drugiego s�owa zostanie usuni�ta ta cz�� wsp�lna. 
  Na koniec zostanie wypisane drugie s�owo (po ewentualnych zmianach). 
*/ 
using namespace std; 
string Znajdz(string Str1="", string Str2="") { 
  //Znajdz - Znajd� wyraz 1 w 2 wyrazie. 
    string Str = ""; 
  //Wyszukanie 1 wyrazu w 2 wyrazie. 
    for(int I = 0; I < Str2.length(); I++) { 
      if(Str2.substr(I, Str1.length()) == Str1) { 
        Str = Str2.substr(0, I)+Str2.substr(I+Str1.length(), Str2.length()); 
        break; 
      } 
    } 
    return Str; 
} 
//Blok g��wny/startowy. 
int main () { 
  cout << "--== Szukaj wyrazu w wyrazie 2 ==--\n"; 
  cout << "Copyright (c)by Jan T. Biernat\n\n"; 
  //Deklaracja zmiennych. 
    string Tekst1 = "", Tekst2 = "", Tekst3 = ""; 
  //Pobranie danych z klawiatury. 
    cout << "Podaj tekst 1: "; getline(cin, Tekst1); 
    cout << "Podaj tekst 2: "; getline(cin, Tekst2); 
  //Wy�wietlenie podanych danych przez u�ytkownika. 
    cout << "\nTekst 1: \"" << Tekst1 << "\"."; 
    cout << "\nTekst 2: \"" << Tekst2 << "\"."; 
  //Wyszukanie 1 wyrazu w 2 wyrazie. 
    Tekst3 = Znajdz(Tekst1, Tekst2); 
    if(Tekst3 != "") { 
      cout << "\n\nZnaleziono w drugim wyrazie pierwszy wyraz!"; 
      cout << "\nDrugie slowo po usunieciu czesci wspolnej: \"" << Tekst3 << "\"."; 
    } 
  //Czekaj, a� u�ytkownik naci�nie klawisz ENTER. 
    cout << "\n\nNacisnij klawisz ENTER..."; 
    getch(); 
} 