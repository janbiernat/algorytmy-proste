#include <iostream> 
#include <conio.h> 
/*--== Statystyka wyraz�w ==-- 
  Copyright (c)by Jan T. Biernat*/ 
using namespace std; 
long int ZnakiBezSpacji(string Tekst="") { 
  string T = ""; 
  //Policz wszystkie znaki, bez znaku spacji (tzw. znaku pustego). 
    if(Tekst != "") { 
      for(int I = 0; I < Tekst.length(); I++) { 
        if(Tekst[I] != ' ') { T = T+Tekst[I]; } 
      } 
    } 
    return T.length(); 
} 
long int WyrazowJest(string Tekst="") { 
  long int L = 0; 
  Tekst = Tekst+char(32); //Dodanie do podanego ci�gu znak�w, znaku spacji (tzw. znaku pustego). 
  //Oblicz, ile jest wyraz�w w podanym ci�gu znak�w. 
    if(Tekst != "") { 
      for(int I = 0; I < Tekst.length(); I++) { 
        if((Tekst[I] != ' ') && (Tekst[I+1] == ' ')) { L++; } //Zapis "L++;" = "L = L+1;". 
      } 
    } 
    return L; 
} 
//Blok g��wny/startowy. 
int main () { 
  cout << "--== Statystyka wyrazow ==--\n"; 
  cout << "Copyright (c)by Jan T. Biernat\n\n"; 
  //Deklaracja zmiennych. 
    string Tekst = ""; 
  //Pobranie danych z klawiatury. 
    cout << "Podaj tekst: "; getline(cin, Tekst); 
  //Statystyka wyraz�w - raport. 
    cout << "\nTekst \"" << Tekst << "\" posiada: "; 
    cout << "\na) wyrazow           : " << WyrazowJest(Tekst); 
    cout << "\nb) znakow bez spacji : " << ZnakiBezSpacji(Tekst); 
    cout << "\nc) znakow ze spacjami: " << Tekst.length(); 
  //Czekaj, a� u�ytkownik naci�nie klawisz ENTER. 
    cout << "\n\nNacisnij klawisz ENTER..."; 
    getch(); 
} 