#include <iostream> 
#include <conio.h> 
/*--== �rednia arytmetyczna ocen - w2 ==-- 
  Copyright (c)by Jan T. Biernat 
  = 
  Tre�� zadania: 
  Napisz program do obliczania �redniej arytmetycznej podanych ocen cz�stkowych. 
  Program musi spe�nia� nast�puj�ce kryteria: 
  > Program do oblicze� ma przyjmowa� tylko liczby z przedzia�u od 1 do 6. 
  > Po uruchomieniu u�ytkownik mo�e od razu wprowadza� oceny. 
  > Zako�czenie wprowadzania ocen nast�puje po wpisaniu cyfry mniejszej od 1 (np. liczby 0). 
  > Po zako�czeniu wprowadzania ocen program ma wy�wietli� raport zawieraj�cy: 
    - Sum� podanych ocen. 
    - Ilo�� podanych ocen. 
    - �redni� podanych ocen. 
    - Procentowy udzia� poszczeg�lnych ocen w stosunku do wszystkich podanych ocen. 
 
  Poni�ej przedstawiono przyk�adowy raport: 
  Raport: 
  Suma podanych ocen wynosi   : 30,5 
  Podanych ocen jest          : 12 
  �rednia podanych ocen wynosi: 2,54 
  Ilo�� poszczeg�lnych ocen: 
    5.0: 2 (16,67%) 
    4.5: 1 (8,33%) 
    4.0: 2 (16,67%) 
    3.5: 1 (8,33%) 
    3.0: 2 (16,67%) 
    2.0: 3 (25%) 
    1.0: 1 (8,33%) 
*/ 
using namespace std; 
//Blok g��wny/startowy. 
int main() { 
  cout <<"--== Srednia arytmetyczna ocen - w2 ==--\n"; 
  cout <<"Copyright (c)by Jan T. Biernat\n\n"; 
  //Deklaracja sta�ych. 
    const short int OcenyIlosc = 11; 
  //Deklaracja zmiennych. 
    int LicznikPytan = 0, LicznikOcen = 0; 
    float Ocena = 0, Suma = 0; 
    float OcenyLista[OcenyIlosc] = { 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5, 5.5, 6 }; 
    int Oceny[OcenyIlosc]; 
    short int OcenaPrawdlowa = 0; //0 - oznacza ocen� nieprawid�ow�. 
  //Wyzerowanie zmiennej tablicowej "Oceny". 
    for(int I = 0; I < OcenyIlosc; I++) { Oceny[I] = 0; } 
  //Pobierz dane z klawiatury. 
    do { 
      LicznikPytan++; //Inkrementacja, czyli zwi�kszenie zmiennej 
                      //liczbowej ca�kowitej o warto�� 1. 
      cout << "Ocena " << LicznikPytan << ": "; 
      Ocena = 0; 
      cin >> Ocena; 
      if(Ocena > 0) { 
        //Je�eli podana ocena jest wi�ksza od 0, to wykonaj poni�sze instrukcje. 
          //Sprawd�, czy ocena zosta�a prawid�owa wpisana przez u�ytkownika. 
          OcenaPrawdlowa = 0; 
          for(int Spr = 0; Spr < OcenyIlosc; Spr++) { 
            if(Ocena == OcenyLista[Spr]) { OcenaPrawdlowa = 1; break; } 
          } 
          if(OcenaPrawdlowa == 1) { 
            //Je�eli podana ocena jest prawid�owa, to wykonaj poni�sze instrukcje. 
              LicznikOcen++; //Licz ilo�� podanych ocen. 
              for(int S = 0; S < OcenyIlosc; S++) { 
                if(Ocena == OcenyLista[S]) { Oceny[S]++; } 
              } 
              Suma = Suma+Ocena; 
          } else { cout << "BLAD -?Ocena z poza zakresu!\n\n"; } 
      } 
    } while(Ocena > 0); 
  //Raport 
    if(LicznikOcen > 0) { 
      //Je�eli u�ytkownik poda� przynajmniej 1 ocen�, to wykonaj poni�sze instrukcje. 
        cout << "\n\nRaport:"; 
        cout << "\n  Suma podanych ocen   : " << Suma; 
        cout << "\n  Ilosc podanych ocen  : " << LicznikOcen; 
        cout << "\n  Srednia podanych ocen: " << (Suma/LicznikOcen); 
        cout << "\n\nUdzial poszczegolnych ocen: "; 
        for(int S = 0; S < OcenyIlosc; S++) { 
          cout << "\n"; 
          if(S % 2 == 0) { cout << "  "; } 
          cout << OcenyLista[S] << ": " << Oceny[S] << " (" << (Oceny[S]*100/LicznikOcen) << "%)"; 
        } 
    } 
  //Naci�nij dowolny klawisz. 
    cout << "\n\nNacisnij dowolny klawisz..."; 
    getch(); 
} 