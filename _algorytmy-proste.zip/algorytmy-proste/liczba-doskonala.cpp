#include <iostream> //Obs�uga strumieni (np. przesy�anie danych na ekran). 
#include <conio.h>  //Obs�uga klawiatury. 
using namespace std; 
/*--== Liczba doskona�a ==-- 
  Copyright (c)by Jan T. Biernat 
  == 
  Liczby naturalne - mat. to liczby 1, 2, 3, ... (niekt�re definicje zaliczaj� do nich r�wnie� 0). 
  Liczba doskona�a - mat. liczba naturalna r�wna sumie wszystkich 
                     swoich dzielnik�w mniejszych od niej samej. 
  Powy�sze definicje pochodz� z encyklopedii PWN. 
  = 
  Przyk�ady liczb doskona�ych, s� poni�ej. 
  Przyk�ad 1. 
              Liczba 6 jest doskona�a, poniewa�: 1+2+3 = 6 
              Liczby 1, 2 i 3 to podzielniki liczby 6 mniejsze od 6. 
  Przyk�ad 2. 
              Liczba 28 jest doskona�a, poniewa�: 1+2+4+7+14 = 28 
              Liczby 1, 2, 4, 7, 14 to podzielniki liczby 28 mniejsze od 28. 
  Przyk�ad 3. 
              Liczba 496 jest doskona�a, poniewa�: 1+2+4+8+16+31+62+124+248 = 496 
              Liczby 1, 2, 4, 8, 16, 31, 62, 124, 248 to jedyne podzielniki liczby 496 mniejsze od 496. 
  = 
  Kolejne liczby doskona�e to: 8 128, 33 550 336, 8 589 869 056, 137 438 691 328, ... . 
  Wszystkie znane dotychczas liczby doskona�e (jest ich 39) s� parzyste. <- za encyklopedi� PWN. 
*/ 
long int LiczbaDoskonala(long int Liczba = 0) { 
  //LiczbaDoskonala - funkcja sprawdza, czy podana liczba jest liczb� doskona��. 
    long int Wynik = 0; 
    if(Liczba > 0) { 
      for(int I = 1; I < Liczba; I++) { 
        if(Liczba % I == 0) { Wynik += I; } 
      } 
      if(Wynik == Liczba) { return Liczba; } else { return 0; } 
    } else { return 0; } 
} 
int main() { 
  cout << "--== Liczba doskonala ==--\n"; 
  cout << "Copyright (c)by Jan T. Biernat\n\n"; 
  //Deklaracja zmiennych liczbowych. 
    long int Liczba = 0; 
  //Pobierz dane z klawiatury. 
    cout << "Liczba: "; cin >> Liczba; 
  //Wywo�anie funkcji "LiczbaDoskonala". 
    cout << "\n" << Liczba << " <-- jest liczba "; 
    if(LiczbaDoskonala(Liczba) > 0) { cout << "doskonala."; } 
    else { cout << "naturalna."; } 
  //Naci�nij dowolny klawisz. 
    cout << "\n\nNacisnij dowolny klawisz..."; 
    getch(); 
} 