/*--== Borland C++Builder (Console Application) ==-- 
                                Kurs podstawowy 
  Copyright(c)by Jan T. Biernat*/ 
#include <iostream> /*Biblioteka IOSTREAM (ang. input/output stream) 
                      oznacza strumie� wej�ciowy/wyj�ciowy. 
                      Za pomoc� tej biblioteki mo�na wprowadza� 
                      informacje ze standardowych urz�dze� 
                      wej�cia (np. klawiatura) lub wyprowadza� 
                      informacje na standardowe urz�dzenia 
                      wyj�cia (np. ekran).*/ 
#include <conio.h> //Biblioteka posiada funkcje do obs�ugi klawiatury. 
using namespace std; /*Za pomoc� s��w kluczowych "using namespace" 
                       informujemy kompilator, �e chcemy aby 
                       wszystkie funkcje, klasy i szablony nale��ce 
                       do przestrzeni nazw nie wymaga�y przedrostka. 
                       Wyraz wyst�puj�cy po tych dw�ch s�owach 
                       kluczowych jest istniej�c� nazw� przestrzeni. 
                       Dla standardowych bibliotek C++ jest to "std".*/ 
int main() { 
  short int iOdp = 0; 
  float A = 0, B = 0, Wynik = 0; 
  do { 
       cout << "--== Prosty kalkulator ==--"; 
       cout << "\n1 - Dodawanie, 2 - Odejmowanie" 
            << "\n3 - Mnozenie, 4 - Dzielenie" 
            << "\nCo wybierasz?: "; 
       cin >> iOdp; 
       if((iOdp > 0) && (iOdp < 5)) { 
         //Wy�wietl nazw� dzia�ania. 
           cout << "\n("; 
           if(iOdp == 1) { cout << "+"; } 
           else if(iOdp == 2) { cout << "-"; } 
                else if(iOdp == 3) { cout << "*"; } 
                     else if(iOdp == 4) { cout << "/"; } 
           cout << "):"; 
         //Pobierz dane z klawiatury. 
           if((iOdp > 0) && (iOdp < 5)) { 
             cout << "\nA: "; 
             cin >> A; 
             cout << "B: "; cin >> B; 
           } 
         //Wykonaj wybrane dzia�anie. 
           Wynik = 0; 
           if(iOdp == 1) { Wynik = A+B; cout << A << " + " << B; } 
           else if(iOdp == 2) { Wynik = A-B; cout << A << " - " << B; } 
                else if(iOdp == 3) { Wynik = A*B; cout << A << " * " << B; } 
                     else if(iOdp == 4) { 
                            if(B != 0) { Wynik = A/B; cout << A << " / " << B; } 
                          } 
         //Wy�wietl wynik dzia�ania.  
           if((iOdp > 0) && (iOdp < 5)) { 
             cout << " = "; 
             if((iOdp == 4) && (B == 0)) { cout << "BLAD -?Dzielenie przez zero jest niewykonalne!"; } 
             else { cout << Wynik; } 
           } 
       } else if(iOdp > 4) { cout << "BLAD -?Nie ma takie opcji!\n       Prosze wybrac inna opcje."; } 
       cout << "\n\n"; 
  } while(iOdp > 0); 
} 