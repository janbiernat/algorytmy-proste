#include <iostream> 
#include <conio.h> 
/*--== Tagi HTML'owe - Formatowanie ==-- 
  Copyright (c)by Jan T. Biernat 
  = 
  Tre�� zadania: 
  Napisz program, kt�ry przerobi wszystkie tagi HTML'owe 
  na du�e litery, tzn. wszystkie litery pomi�dzy znakami 
  "<" a ">" zamieni na du�e za wyj�tkiem styli. 
  Style maj� by� pisane ma�ymi literami i znajduj� si� 
  pomi�dzy znakami cudzys�owia (tj. "). 
 
  Przyk�ad: 
  Zawarto�� pliku wej�ciowego: 
  <html><hEAd><TITLE>Nazwa strony</Title></head><body>pt. "<font style="fONt-weIght:boLd;">Terminator 1</fonT>". Dowolny TEKST </boDy></html> 
 
  Plik wyj�ciowy: 
  <HTML><HEAD><TITLE>Nazwa strony</TITLE></HEAD><BODY>pt. "<FONT STYLE="font-weight:bold;">Terminator 1</FONT>". Dowolny TEKST </BODY></HTML> 
*/ 
using namespace std; 
string tagi_html_formatowanie(string Str = "") { 
  //tagi_html_formatowanie - funkcja zwraca sformatowane znaczniki i arkusze styli. 
    int A = 0, B = 0; 
    short int Jest = 0; 
    if(Str != "") { 
      for(A = B; A < Str.length(); A++) { 
        if(Str[A] == '<') { 
          for(B = A+1; B < Str.length(); B++) { 
            if(Str[B] == '>') { break; } 
            else { 
                   if(Jest == 0) { 
                     if((int(Str[B]) > 96) && (int(Str[B]) < 123)) { Str[B] = char(int(Str[B])-32); } 
                     if(Str[B] == '"') { Jest = 1; } 
                   } else { 
                            if((int(Str[B]) > 64) && (int(Str[B]) < 91)) { Str[B] = char(int(Str[B])+32); } 
                            if(Str[B] == '"') { Jest = 0; } 
                          } 
                 } 
          } 
        } 
      } 
      return Str; 
    } else { return "BLAD -?Brak podanego ciagu znakow!"; } 
} 
//Blok g��wny/startowy. 
int main () { 
  cout <<"--== Tagi HTML'owe - Formatowanie ==--\n"; 
  cout <<"Copyright (c)by Jan T. Biernat\n\n"; 
  //Deklaracja zmiennych. 
    string Tekst = ""; 
  //Pobierz dane z klawiatury. 
    cout << "Podaj tekst: "; 
    getline(cin, Tekst); 
    cout << "\"" << Tekst << "\".\n= \"" << tagi_html_formatowanie(Tekst) << "\"."; 
  //Naci�nij dowolny klawisz. 
    cout << "\n\nNacisnij dowolny klawisz..."; 
    getch(); 
/* 
  Legenda: 
    int(Str[B]) - Odczytanie kodu w systemie dziesi�tnym znaku, kt�ry jest przechowywany 
                  w zmiennej tekstowej "Str" pod podanym nr indeksu. Nr indeksu jest przechowywany 
                  przez zmienn� liczbow� ca�kowit� "B". 
    char(int(Str[B])-32) - Odczytanie kodu dziesi�tnego podanego znaku 
                           (znak jest przechowywany w zmiennej tekstowej "Str" 
                            pod nr indeksu, kt�ry jest przechowywany przez 
                            zmienn� liczbow� ca�kowit� "B"). 
                           Nast�pnie od odczytanego kodu odj�ta jest warto�� 32 
                           i po wykonaniu tych dzia�a� nast�puje wy�wietlenie znaku 
                           (za pomoc� instrukcji "char"). 
*/ 
} 