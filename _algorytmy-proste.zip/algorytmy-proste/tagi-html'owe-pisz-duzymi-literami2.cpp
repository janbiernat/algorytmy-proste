#include <iostream> 
#include <conio.h> 
#include <fstream> //Posiada funkcje zwi�zane z obs�ug� plik�w. 
/*--== Tagi HTML'owe pisz du�ymi literami 2 ==-- 
  Copyright (c)by Jan T. Biernat 
  = 
  Tre�� zadania: 
  Napisz program, kt�ry przerobi wszystkie tagi HTML'owe 
  na du�e litery, tzn. wszystkie litery pomi�dzy znakami 
  "<" a ">" zamieni na du�e. 
  Dane nale�y pobra� z pliku tekstowego, natomiast 
  wynik dzia�ania programu zapisa� do nowego pliku tekstowego. 
 
  Przyk�ad: 
  Zawarto�� pliku wej�ciowego: 
  <html> 
    <head> 
       <TITLE>Nazwa strony</Title> 
    </head> 
    <body> 
       <b>Cos tam</b> 
       Dowolny TEKST 
    </body> 
    </html> 
 
  Plik wyj�ciowy: 
  <HTML> 
    <HEAD> 
      <TITLE>Nazwa strony</TITLE> 
    </HEAD> 
    <BODY> 
      <B>Cos tam</B> 
      Dowolny TEKST 
    </BODY> 
    </HTML> 
*/ 
using namespace std; 
string tagi_html_na_TAGI_HTML(string Str = "") { 
  //tagi_html_na_TAGI_HTML - Zamienia wszystkie znaczniki HTML na du�e. 
    int A = 0, B = 0; 
    if(Str != "") { 
      for(A = B; A < Str.length(); A++) { 
        if(Str[A] == '<') { 
          for(B = A; B < Str.length(); B++) { 
            if(Str[B] == '>') { break; } 
            else { 
                   if(int(Str[B]) > 96) { Str[B] = char(int(Str[B])-32); } 
                 } 
          } 
        } 
      } 
      return Str; 
    } else { return ""; } 
} 
//Blok g��wny/startowy. 
int main() { 
  cout <<"--== Tagi HTML'owe pisz duzymi literami 2 ==--\n"; 
  cout <<"Copyright (c)by Jan T. Biernat\n\n"; 
  //Deklaracja zmiennych. 
    string Linia = "", LiniaPoZmianie = ""; 
    long int Licznik = 0; 
  //Konwertowanie danych. 
    fstream PlikDane("index.html", ios::in); //1 
  //Pobranie danych z pliku. 
    if(PlikDane != NULL) { //2 
      fstream PlikDaneWynikowe("index-wynik.html", ios::out | ios::trunc); //3 
      Linia = ""; 
      while(getline(PlikDane, Linia)) { //4 
        Licznik++; 
        cout << "\n" << Licznik << ": " << Linia; 
        LiniaPoZmianie = ""; LiniaPoZmianie = tagi_html_na_TAGI_HTML(Linia); 
        if(Licznik > 1) { PlikDaneWynikowe << "\n"; } 
        PlikDaneWynikowe << LiniaPoZmianie; 
      } 
      PlikDaneWynikowe.close(); //5 
    } else { cout << "BLAD -?Brak pliku o podanej nazwie na dysku!\n"; } 
    PlikDane.close(); //5 
  //Naci�nij dowolny klawisz. 
    cout << "\n\nNacisnij dowolny klawisz..."; 
    getch(); 
/* 
  Legenda: 
    1) Utworzenie obiektu o nazwie "PlikDane" na podstawie klasy "fstream". 
       Od tego momentu mo�na u�ywa� instrukcji, kt�re nale�� do klasy "fstream". 
       Otwarcie pliku do odczytu (tj. ios::in). 
    2) Je�eli warunek jest spe�niony, czyli obiekt "PlikDane" przechowuje 
       warto�� r�n� od NULL, to plik istnieje fizycznie na dysku. 
       Gdy plik istnieje fizycznie na dysku, to nast�pi jego odczyt linia po linii. 
    3) Utworzenie obiektu o nazwie "PlikDaneWynikowe" na podstawie klasy "fstream". 
       Od tego momentu mo�na u�ywa� instrukcji, kt�re nale�� do klasy "fstream". 
       Otwarcie pliku do zapisu (tj. ios::out) i zredukowanie rozmiaru pliku do zera 
       (tj. ios::trunc), je�eli plik wcze�niej istnia�. 
       Skr�t: trunc pochodzi do s�owa ang. truncate - skraca�, skr�ci� (dotyczy czasu). 
    4) Odczytanie kolejnej linii. Odczyt b�dzie kontynuowany, do momentu 
       napotkania ko�ca pliku. 
    5) Zamkni�cie strumienia (w tym przyk�adzie) pliku tekstowego. 
*/ 
} 