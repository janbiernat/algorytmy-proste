#include <iostream> 
#include <conio.h> 
#include <fstream> //Posiada funkcje zwi�zane z obs�ug� plik�w. 
using namespace std; 
/*--== CSV to table 3 - Zapisz do pliku tekstowego ==-- 
  Copyright (c)by Jan T. Biernat 
  = 
  Napisz program, kt�ry dokona konwersji danych 
  z formatu CSV na reprezentacj� tabelaryczn�. 
  Znakiem oddzielaj�cym dane jest �rednik (tj. znak ";"). 
 
  Na przyk�ad: 
    Dane wej�ciowe: 
      nazwisko;imie;wiek 
      Kowalski;Jan;47 
      Chleb;Justyna;28 
 
    Dane wyj�ciowe: 
      +---------------------------+ 
      | nazwisko | imie    | wiek | 
      |---------------------------| 
      | Kowalski | Jan     |   47 | 
      |---------------------------| 
      | Chleb    | Justyna |   28 | 
      +---------------------------+ 
  = 
  CSV (ang. comma-separated values, warto�ci rozdzielone przecinkiem) 
  Format przechowywania danych w plikach tekstowych. 
  Jako separatora tekstu (danych) mo�na u�ywa�: �rednika, przecinka 
  lub innego znaku (najlepiej nieu�ywanego w tek�cie). 
*/ 
class csv_do_tabeli { 
  //Utworzenie klasy o nazwie "csv_do_tabeli". 
    public: 
      int ile_znakow; 
      int IloscZnakow(string Str); 
      string LiniaPozioma(int IleZnakow); 
      string WyswietlDane(string Str, int IleZnakow); 
}; 
int csv_do_tabeli::IloscZnakow(string Str = "") { 
  //IloscZnakow. 
  //Podaje najwi�ksz� liczb� okre�laj�c� ile znak�w mie�ci si� pomi�dzy znakami �rednika (tj. znakiem ";"). 
    int ZnakiLicznik = 0, ZnakiMaks = 0; 
    if(Str != "") { 
      for(int I = 0; I < Str.length(); I++) { 
        if(Str[I] == ';') { 
          if(ZnakiLicznik > ZnakiMaks) { ZnakiMaks = ZnakiLicznik; } 
          ZnakiLicznik = 0; 
        } else { ZnakiLicznik++; } 
      } 
      return ZnakiMaks; 
    } else { return -1; } 
} 
string csv_do_tabeli::LiniaPozioma(int IleZnakow = 0) { 
  //LiniaPozioma - Rysuje lini� poziom�. 
    string LiniaPoziomaT = ""; 
    if(IleZnakow > 0) { 
      LiniaPoziomaT = "+"; 
      for(int I = 0; I < IleZnakow; I++) { LiniaPoziomaT += "-"; } 
      LiniaPoziomaT += "+"; 
      return LiniaPoziomaT; 
    } else { return "?"; } 
} 
string csv_do_tabeli::WyswietlDane(string Str = "", int IleZnakow = 0) { 
  //WyswietlDane - Wy�wietla na ekranie dane w formie tabelarycznej. 
    string T1 = "", T2 = "", Spacja = ""; 
    short int CzyZnaki = 0; 
    int Licznik = 0; 
    if(Str != "") { 
      for(int I = 0; I < Str.length(); I++) { 
        if(Str[I] == ';') { //1. 
          Spacja = ""; 
          for(int S = 0; S < IleZnakow-T1.length(); S++) { Spacja+= " "; } 
          CzyZnaki = 0; 
          for(int V = 0; V < T1.length(); V++) { 
            if((T1[V] < '0') || (T1[V] > '9')) { CzyZnaki = 1; break; } 
          } 
          if(CzyZnaki == 0) { T2+= " | "+Spacja+T1; } 
          else { T2+= " | "+T1+Spacja; } 
          T1 = ""; 
        } else { T1+= Str[I]; } //2. 
      } 
      ile_znakow = 0; ile_znakow = T2.length()-1; 
      return "\n"+T2+" |"; 
    } else { return "?"; } 
/* 
  Legenda: 
    1) Zapis "Str[I]" umo�liwia odczytanie znaku ze zmiennej tekstowej "Str" na podstawie 
       podanego numeru indeksu. Nr indeksu jest przechowywany w zmiennej liczbowej ca�kowitej "I". 
       Po odczytaniu znaku, nast�puje por�wnanie go z praw� stron� warunku. 
       Je�eli warunek jest spe�niony, to wykonaj instrukcje w klamrach (zaraz za warunkiem IF). 
       W przeciwnym razie wykonaj instrukcje po s�owie ELSE (tj. dodaj do zmiennej tekstowej 
       "T1" kolejne odczytane znaki ze zmiennej tekstowej "Str"). 
    2) Je�eli warunek "if(Str[I] == ';')" jest niespe�niony, to wykonaj instrukcje po s�owie ELSE. 
       Dodaj do zmiennej tekstowej "T1" kolejne odczytane znaki ze zmiennej tekstowej "Str". 
       Zapis "T1+= Str[I];" jest r�wnowa�ny z zapisem "T1 = T1+Str[I];". 
*/ 
} 
//Blok g��wny/startowy. 
int main(int argc, char *argv[]) { 
  cout << "--== CSV to table 3 - Zapisz do pliku tekstowego ==--\n"; 
  cout << "Copyright (c)by Jan T. Biernat\n\n"; 
  //Deklaracja zmiennych. 
    string Linia = "", WierszDane = ""; 
    long int Licznik = 0; 
    int Ile = 0, Maks = 0; 
    csv_do_tabeli do_tabeli; //Deklaracja obiektu o nazwie "do_tabeli". 
  //Znajd� najd�u�szy ci�g znak�w. 
    fstream PlikDane(argv[1], ios::in); //1. 
    if(PlikDane != NULL) { 
      Linia = ""; 
      while(getline(PlikDane, Linia)) { 
        Ile = do_tabeli.IloscZnakow(Linia+';'); 
        if(Ile > Maks) { Maks = Ile; } 
      } 
    } else { cout << "BLAD -?Brak pliku o podanej nazwie na dysku!\n"; } 
    PlikDane.close(); 
  //Wy�wietl dane w formie tabelarycznej. 
    Licznik = 0; 
    fstream PobierzDane(argv[1], ios::in); 
      fstream PlikZapisz("wynik.txt", ios::out | ios::trunc); //2. 
      if(PobierzDane != NULL) { 
        Linia = ""; 
        while(getline(PobierzDane, Linia)) { 
          Licznik++; 
          WierszDane = ""; WierszDane = do_tabeli.WyswietlDane(Linia+';', Maks); 
          if(Licznik == 1) { 
            PlikZapisz << " " << do_tabeli.LiniaPozioma(do_tabeli.ile_znakow); 
            cout << "\n " << do_tabeli.LiniaPozioma(do_tabeli.ile_znakow); 
          } 
          PlikZapisz << WierszDane; 
          cout << WierszDane; 
          PlikZapisz << "\n " << do_tabeli.LiniaPozioma(do_tabeli.ile_znakow); 
          cout << "\n " << do_tabeli.LiniaPozioma(do_tabeli.ile_znakow); 
        } 
      } else { cout << "BLAD -?Brak pliku o podanej nazwie na dysku!\n"; } 
      PlikZapisz.close(); 
    PobierzDane.close(); 
  //Czekaj, a� u�ytkownik naci�nie klawisz ENTER. 
    cout << "\n\n\nNacisnij klawisz ENTER..."; 
    getch(); 
/* 
  Legenda: 
    1) Utworzenie obiektu o nazwie "PlikDane" na podstawie klasy "fstream". 
       Od tego momentu mo�na u�ywa� instrukcji, kt�re nale�� do klasy "fstream". 
       Otwarcie pliku do odczytu (tj. ios::in). 
    2) Utworzenie obiektu o nazwie "PlikZapisz" na podstawie klasy "fstream". 
       Od tego momentu mo�na u�ywa� instrukcji, kt�re nale�� do klasy "fstream". 
       Otwarcie pliku do zapisu (tj. ios::out) i zredukowanie rozmiaru pliku do zera 
       (tj. ios::trunc), je�eli plik wcze�niej istnia�. 
       Skr�t: trunc pochodzi do s�owa ang. truncate - skraca�, skr�ci� (dotyczy czasu). 
*/ 
} 