#include <iostream> 
#include <conio.h> 
#include <fstream> 
using namespace std; 
/*--== Egzamin zawodowy teoretyczny - Sprawdzenie odpowiedzi ==-- 
  Copyright (c)by Jan T. Biernat 
 */ 
//------------------------------------------------------------------------------ 
string ZNAKI_na_znaki(string Str = "") { 
//ZNAKI_na_znaki - Funkcja zamienia wszystkie znaki na ma�e. 
  string T = ""; 
  for(int I = 0; I < Str.length(); I++) { 
    if(((int)Str[I] > 64) && ((int)Str[I] < 91)) { T = T+char((int)Str[I]+32); } 
    else { T += Str[I]; } 
  } 
  return T; 
} 
//------------------------------------------------------------------------------ 
string znaki_na_ZNAKI(string Str = "") { 
//znaki_na_ZNAKI - Funkcja zamienia wszystkie znaki na du�e. 
  string T = ""; 
  for(int I = 0; I < Str.length(); I++) { 
    if(((int)Str[I] > 96) && ((int)Str[I] < 123)) { T = T+char((int)Str[I]-32); } 
    else { T += Str[I]; } 
  } 
  return T; 
} 
//------------------------------------------------------------------------------ 
string ZnakiTylko(string Str = "") { 
//ZnakiTylko - Funkcja zwraca tylko znaki od 0 do 9 i od A do D. 
  string T = ""; 
  short int Start = 0; 
  if(Str[0] == '0') { Start = 1; } 
  for(int I = Start; I < Str.length(); I++) { 
    if((((int)Str[I] > 47) && ((int)Str[I] < 58)) 
    || (((int)Str[I] > 64) && ((int)Str[I] < 69))) { T+= Str[I]; } 
  } 
  return T; 
} 
//------------------------------------------------------------------------------ 
string PobierzSciezke(string Str = "") { 
//PobierzSciezke - Funkcja zwraca �cie�k� dost�pu do pliku. 
  int I = 0; 
  if(Str != "") { 
    Str = ZNAKI_na_znaki(Str); 
    for(I = Str.length(); I > -1; I--) { 
      if(Str[I] == '\\') { break; } 
    } 
    return Str.substr(0, I+1); 
  } else { return "-?"; } 
} 
//------------------------------------------------------------------------------ 
//Blok g��wny(startowy). 
int main(int argc, char *argv[]) { 
  cout << "--== Egzamin zawodowy teoretyczny - Sprawdzenie odpowiedzi ==--\n"; 
  cout << "Copyright (c)by Jan T. Biernat\n\n\n"; 
  cout << "UWAGA: Program umozliwia sprawdzenie poprawnosci podanych odpowiedzi.\n" 
       << "Dotyczy to tylko testu jednokrotnego wyboru (tzn. testu, w ktorym jest\n" 
       << "tylko 1 poprawna odpowiedz z 4 odpowiedzi proponowanych).\n\n"; 
  //Deklaracja sta�ych. 
    const int PytaniaIlosc = 41; 
    const string KomunikatBlad = " <- Zle!"; 
  //Deklaracja zmiennych. 
    string Tablica1[PytaniaIlosc+1], Tablica2[PytaniaIlosc+1]; 
    string PlikSpr = "", PlikWzorcowy = "", Linia = ""; 
    int Licznik1 = 0, Licznik2 = 0, DobrychIlosc = 0; 
    float Wynik = 0; 
  //Wyczy�� tablice. 
    for(int I = 0; I < PytaniaIlosc+1; I++) { Tablica1[I] = ""; } 
    for(int I = 0; I < PytaniaIlosc+1; I++) { Tablica2[I] = ""; } 
  //Wczytaj plik do sprawdzenia. 
    fstream PlikDaneSpr(argv[1], ios::in); 
    if(PlikDaneSpr != NULL) { 
      PlikSpr = ZNAKI_na_znaki(argv[1]); 
      PlikWzorcowy = PobierzSciezke(PlikSpr)+"wzor.txt"; 
      cout << "\nOdczytany plik do sprawdzenia: \"" << PlikSpr << "\"."; 
      Linia = ""; 
      while(getline(PlikDaneSpr, Linia)) { 
        if(Linia != "") { 
          if(Licznik2 < PytaniaIlosc-1) { 
            Tablica2[Licznik2] = ZnakiTylko(znaki_na_ZNAKI(Linia)); 
            Tablica2[Licznik2] = Tablica2[Licznik2].substr(0, 3); 
            Licznik2++; 
          } else { break; } 
        } 
      } 
      //Wczytaj plik (wzorcowy) z prawid�owymi odpowiedziami. 
        fstream PlikDaneWzor(PlikWzorcowy.c_str(), ios::in); 
        if(PlikDaneWzor != NULL) { 
          cout << "\nOdczytany plik wzorcowy: \""<< PlikWzorcowy <<"\".\n"; 
          Linia = ""; 
          while(getline(PlikDaneWzor, Linia)) { 
            if(Linia != "") { 
              if(Licznik1 < PytaniaIlosc-1) { 
                Tablica1[Licznik1] = ZnakiTylko(znaki_na_ZNAKI(Linia)); 
                Tablica1[Licznik1] = Tablica1[Licznik1].substr(0, 3); 
                Licznik1++; 
              } else { break; } 
            } 
          } 
        } else { cout << "\nBLAD -?Brak pliku wzorcowego o nazwie \"WZOR.TXT\"!"; } 
        PlikDaneWzor.close(); 
    } else { cout << "\nBLAD -?Brak pliku do sprawdzenia!\n\n\n"; 
             cout << "Instrukcja obslugi:\n" 
                  << "Schemat odpowiedzi na podstawie ktorych bedzie przeprowadzona weryfikacja, nalezy\n" 
                  << "umiescic w pliku tekstowym pod nazwa \"wzor.txt\". Nastepnie plik z odpowiedziami\n" 
                  << "do sprawdzenia nalezy wywolac razem z programem. Na przyklad: \"egz_spr.exe spr_t1.txt\".\n" 
                  << "Po wywolaniu programu EGZ_SPR.EXE z parametrem SPR_T1.TXT, nastapi wczytanie zawartosci\n" 
                  << "pliku \"wzor.txt\" oraz pliku \"spr_t1.txt\".\n" 
                  << "Zarowno plik \"wzor.txt\", jak i plik \"spr_t1.txt\" powinien znajdowac sie w tym samym katalogu/folderze.\n" 
                  << "Potem odpowiedzi z pliku \"spr_t1.txt\" zostana porownane z odpowiedziami\n" 
                  << "z pliku \"wzor.txt\" i na koncu zostanie wyswietlona informacja w procentach\n" 
                  << "okreslajaca ilosc poprawnych odpowiedzi."; 
           } 
    PlikDaneSpr.close(); 
  //Wy�wietl nr pyta� i odpowiedzi. 
    if((Licznik1 > 0) && (Licznik2 > 0)) { 
      cout << "\n\nPorownanie odpowiedzi:\n"; 
      for(int I = 0; I < PytaniaIlosc; I++) { 
        if(Tablica1[I] != "") { 
          cout << "\n "; 
          if(I < 9) { 
            cout << " " << Tablica1[I].substr(0, 2) << "    " << Tablica2[I].substr(0, 2); 
            if(Tablica1[I].substr(0, 2) == Tablica2[I].substr(0, 2)) { DobrychIlosc++; } 
            else { cout << KomunikatBlad; } 
          } else { 
                   cout << Tablica1[I].substr(0, 3) << "   " << Tablica2[I].substr(0, 3); 
                   if(Tablica1[I].substr(0, 3) == Tablica2[I].substr(0, 3)) { DobrychIlosc++; } 
                   else { cout << KomunikatBlad; } 
                 } 
        } 
      } 
      //Ile jest poprawnych odpowiedzi? 
        Wynik = 0; Wynik = (DobrychIlosc*100)/(PytaniaIlosc-1); 
        cout << "\n\nPytan jest     : " << PytaniaIlosc-1; 
        cout << "\nPoprawnych jest: " << DobrychIlosc << " (" << (Wynik) << "%)"; 
        cout << "\nBlednych jest  : " << ((PytaniaIlosc-1)-DobrychIlosc); 
    } 
  //Naci�nij dowolny klawisz. 
    cout << "\n\n\nNacisnij dowolny klawisz ..."; getch(); 
  cout << "\n"; 
} 