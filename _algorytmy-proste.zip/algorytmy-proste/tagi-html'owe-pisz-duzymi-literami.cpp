#include <iostream> 
#include <conio.h> 
/*--== Tagi HTML'owe pisz du�ymi literami ==-- 
  Copyright (c)by Jan T. Biernat 
  = 
  Tre�� zadania: 
  Napisz program, kt�ry przerobi wszystkie tagi HTML'owe 
  na du�e litery, tzn. wszystkie litery pomi�dzy znakami 
  "<" a ">" zamieni na du�e. 
 
  Przyk�ad: 
  Zawarto�� pliku wej�ciowego: 
  <html><head><TITLE>Nazwa strony</Title></head><body><b>Cos tam</b> Dowolny TEKST </body></html> 
 
  Plik wyj�ciowy: 
  <HTML><HEAD><TITLE>Nazwa strony</TITLE></HEAD><BODY><B>Cos tam</B> Dowolny TEKST </BODY></HTML> 
*/ 
using namespace std; 
string tagi_html_na_TAGI_HTML(string Str = "") { 
  //tagi_html_na_TAGI_HTML - Zamienia wszystkie znaczniki HTML na du�e. 
    int A = 0, B = 0; 
    if(Str != "") { 
      for(A = B; A < Str.length(); A++) { 
        if(Str[A] == '<') { 
          for(B = A; B < Str.length(); B++) { 
            if(Str[B] == '>') { break; } 
            else { 
                   if(int(Str[B]) > 96) { Str[B] = char(int(Str[B])-32); } 
                 } 
          } 
        } 
      } 
      return Str; 
    } else { return ""; } 
} 
//Blok g��wny/startowy. 
int main() { 
  cout <<"--== Tagi HTML'owe pisz duzymi literami ==--\n"; 
  cout <<"Copyright (c)by Jan T. Biernat\n\n"; 
  //Deklaracja zmiennych. 
    string Tekst = ""; 
  //Pobierz dane z klawiatury. 
    cout << "Podaj tekst: "; 
    getline(cin, Tekst); 
    cout << "\"" << Tekst << "\"\n= \"" << tagi_html_na_TAGI_HTML(Tekst) << "\"."; 
  //Naci�nij dowolny klawisz. 
    cout << "\n\nNacisnij dowolny klawisz..."; 
    getch(); 
} 