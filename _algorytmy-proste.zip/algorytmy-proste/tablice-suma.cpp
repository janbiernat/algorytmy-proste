#include <iostream> 
#include <conio.h> 
/*--== Tablice jednowymiarowe - Sumowanie ==-- 
  Copyright(c)by Jan T. Biernat*/ 
using namespace std; 
int TablicaSuma(int Tablica[], int Ilosc = 0) { 
  //TablicaSuma - Sumuj wszystkie elementy tablicy. 
    int Suma = 0; 
    if(Ilosc > 0) { 
      for(int I = 0; I < Ilosc; I++) { Suma += Tablica[I]; } 
    } else { cout << "BLAD -?"; } 
    return Suma; 
} 
//Blok g��wny/startowy. 
int main() { 
  cout <<"--== Tablice jednowymiarowe - Sumowanie ==--\n"; 
  cout <<"Copyright(c)by Jan T. Biernat\n\n\n"; 
  //Deklaracja sta�ych. 
    const int IloscElementow = 6; 
  //Deklaracja zmiennych. 
    int Tablica[IloscElementow] = { 0, 1, 10, 3, 5, 7 }; 
  //Wy�wietl zawarto�� tablicy. 
    for(int I = 0; I < IloscElementow; I++) { 
      if(I > 0) { cout << " + "; } 
      cout << Tablica[I]; 
    } 
  //Wy�wietl zawarto�� tablicy. 
    cout << " = " << TablicaSuma(Tablica, IloscElementow); 
  //Naci�nij dowolny klawisz. 
    cout << "\n\nNacisnij dowolny klawisz..."; 
    getch(); 
} 