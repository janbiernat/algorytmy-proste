#include <iostream> 
#include <conio.h> 
/*--== Pot�gowanie ==-- 
 Copyright (c)by Jan T. Biernat 
 = 
 Pot�gowanie jest dzia�aniem matematycznym 
 i polega na wielokrotnym mno�eniu liczby przez sam� siebie. 
 Liczba, kt�r� b�dziemy pot�gowa� nazywa si� podstaw�. 
 Natomiast liczb� okre�laj�c� ile razy pomno�ymy 
 podstaw� przez sam� siebie, nazywa si� wyk�adnikiem. 
*/ 
using namespace std; 
long int Potega(long int Podstawa, int Wykladnik = 0) { 
  long int Wynik = 1; //Przypisz do zmiennej "Wynik" domy�ln� warto�� 1, 
                      //gdy zmienna "Wykladnik" b�dzie przechowywa�a warto�� 0. 
  for(int I = 0; I < Wykladnik; I++) { 
    Wynik *= Podstawa; 
  } 
  return Wynik; 
} 
long int Potega2(long int Podstawa, int Wykladnik = 0) { 
  long int Wynik = 1; //Przypisz do zmiennej "Wynik" domy�ln� warto�� 1, 
                      //gdy zmienna "Wykladnik" b�dzie przechowywa�a warto�� 0. 
  for(int I = 0; I < Wykladnik; I++) { 
    Wynik = Wynik*Podstawa; 
  } 
  return Wynik; 
} 
//Blok g��wny/startowy. 
int main() { 
  cout << "--== Potegowanie ==--\n"; 
  cout << "Copyright (c)by Jan T. Biernat\n\n\n"; 
  //Deklaracja zmiennych znakowych. 
    int Podstawa = 0, Wykladnik = 0; 
  //Pobierz dane z klawiatury. 
    cout << "Wpisz podstawe : "; cin >> Podstawa; 
    cout << "Wpisz wykladnik: "; cin >> Wykladnik; 
  //Wywo�anie funkcji. 
    cout << "\n" << Podstawa << "^" << Wykladnik << " = " << Potega(Podstawa, Wykladnik); 
    cout << "\n" << Podstawa << "^" << Wykladnik << " = " << Potega2(Podstawa, Wykladnik); 
  //Czekaj, a� u�ytkownik naci�nie klawisz ENTER. 
    cout << "\n\nNacisnij klawisz ENTER..."; getch(); 
} 