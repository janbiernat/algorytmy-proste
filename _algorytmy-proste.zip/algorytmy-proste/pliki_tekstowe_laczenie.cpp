#include <iostream> 
#include <conio.h> 
#include <fstream> //Posiada funkcje zwi�zane z obs�ug� plik�w. 
/*--== Pliki tekstowe - ��czenie plik�w ==-- 
  Copyright (c)by Jan T. Biernat*/ 
using namespace std; 
int main() { 
  cout << "--== Pliki tekstowe - laczenie plikow ==--\n"; 
  cout << "Copyright (c)by Jan T. Biernat\n\n"; 
  //Deklaracja sta�ych. 
    const string PlikAng = "ang.txt"; 
    const string PlikPol = "pol.txt"; 
    const string PlikAngPol = "ang-pol.txt"; 
  //Deklaracja zmiennych. 
    string LiniaAng = "", LiniaPol = "", Razem = ""; 
    long int Licznik = 0; 
  //Kod program. 
    fstream PlikDaneA(PlikAng.c_str(), ios::in); //1 
    fstream PlikDaneP(PlikPol.c_str(), ios::in); 
    fstream PlikDaneW(PlikAngPol.c_str(), ios::out | ios::trunc); //2 
  //Pobranie danych z pliku. 
    if((PlikDaneA != NULL) && (PlikDaneP != NULL)) { //3 
      LiniaAng = ""; LiniaPol = ""; //4 
      while((getline(PlikDaneA, LiniaAng)) && (getline(PlikDaneP, LiniaPol))) { //5 
        Licznik++; //6 
        Razem = ""; 
        Razem = LiniaAng + " <> " + LiniaPol + "."; //7 
        PlikDaneW << Razem << "\n"; //8 
        cout << "\n" << Licznik << ": " << Razem; //9 
      } 
    } else { cout << "BLAD -?Brak pliku o podanej nazwie na dysku!\n"; } 
    PlikDaneA.close(); //10 
    PlikDaneP.close(); 
    PlikDaneW.close(); 
  //Naci�nij dowolny klawisz. 
    cout << "\n\nNacisnij dowolny klawisz..."; 
    getch(); 
/* 
  Legenda: 
   1) Utworzenie obiektu o nazwie "PlikDaneA" na podstawie klasy "fstream". 
      Od tego momentu mo�na u�ywa� instrukcji, kt�re nale�� do klasy "fstream". 
      Otwarcie pliku do odczytu (tj. ios::in). 
      c_str() - Instrukcja wykonuje konwersj� tekstu na tablic� znak�w. 
                Taki zapis umo�liwia przekazanie tekstu jako parametru funkcji 
                w postaci char* lub const char* (w standardzie j�zyka C). 
   2) Utworzenie obiektu o nazwie "PlikDaneW" na podstawie klasy "fstream". 
      Od tego momentu mo�na u�ywa� instrukcji, kt�re nale�� do klasy "fstream". 
      Otwarcie pliku do zapisu (tj. ios::out) i zredukowanie rozmiaru pliku do zera 
      (tj. ios::trunc), je�eli plik wcze�niej istnia�. 
      Skr�t: trunc pochodzi do s�owa ang. truncate - skraca�, skr�ci� (dotyczy czasu). 
   3) Je�eli warunek jest spe�niony, czyli obiekty "PlikDaneA" i "PlikDaneP" przechowuj� 
      warto�� r�n� od NULL, to poszczeg�lne pliki istniej� fizycznie na dysku. 
      Gdy pliki istniej� fizycznie na dysku, to nast�pi ich odczyt linia po linii. 
   4) Wyczyszczenie zmiennych tekstowych. 
   5) Odczytanie kolejnej linii z poszczeg�lnych plik�w. 
      Odczyt b�dzie kontynuowany, do momentu napotkania ko�ca pliku. 
   6) Zapis "Licznik++" = "Licznik = Licznik+1". Oba zapisy s� prawid�owe 
      i oznaczaj� zwi�kszenie zawarto�ci zmiennej liczbowej "Licznik" o warto�� 1. 
   7) Przypisanie do zmiennej tekstowej "Razem" po��czonych ci�g�w znak�w za pomoc� operatora "+". 
   8) Zapisanie pobranych i po��czonych danych do pliku tekstowego. 
   9) Wy�wietlenie na ekranie zawarto�ci zmiennej liczbowe "Licznik", tekstu znajduj�cego si� 
      pomi�dzy cudzys�owami oraz zawarto�ci zmiennej tekstowej "Razem". 
  10) Zamkni�cie pliku. 
*/ 
} 