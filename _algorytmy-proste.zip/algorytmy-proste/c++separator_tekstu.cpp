#include <iostream> 
#include <conio.h> 
using namespace std; 
/*--== Rozdzielanie tekstu (separator tekstu) ==-- 
  Copyright (c)by Jan T. Biernat 
  = 
  Napisz program kt�ry pobierze od u�ytkownika 
  dowolny tekst. Ka�dy wyraz w tek�cie nale�y 
  rozdzieli� znakiem �rednika (tj. ";") 
  tzw. separatorem tekstu. 
  Nast�pnie program ma wypisa� ka�dy wyraz w osobnym wierszu. 
  Na przyk�ad: 
    Podany tekst to: Atari;Spectrum;Amstrad;Amiga;CRY 
    Wynik dzia�ania programu: 
        1) Atari, 
        2) Spectrum, 
        3) Amstrad, 
        4) Amiga, 
        5) CRY. 
*/ 
int main() { 
  cout << "--== Rozdzielanie tekstu (separator tekstu) ==--\n"; 
  cout << "Copyright (c)by Jan T. Biernat\n\n"; 
  //Deklaracja sta�ych. 
    const char ZnakSeparatora = ';'; 
  //Deklaracja zmiennych. 
    string Tekst = "", Tym = ""; 
    int TekstDl = 0, NrPos = 0, Licznik = 0; 
  //Pobierz dane z klawiatury. 
    cout << "Podaj tekst: "; 
    getline(cin, Tekst); 
  //Wykonaj program. 
    if(Tekst != "") {                                                //1. 
      Tekst = Tekst+ZnakSeparatora;                                  //2. 
      TekstDl = 0; TekstDl = Tekst.length();                         //3. 
      for(int I = 0; I < TekstDl; I++) {                             //4. 
        NrPos = 0; NrPos = Tekst.find(ZnakSeparatora);               //5. 
        if(Tekst.substr(0, NrPos) != "") {                           //6. 
          Licznik++;                                                 //7. 
          if(I > 0) { cout << ","; }                                 //8. 
          cout << "\n";                                              //9. 
          cout.width(3);                                             //10. 
          cout << Licznik << ") " << Tekst.substr(0, NrPos);         //11. 
        } 
        Tym = ""; Tym = Tekst.substr(NrPos+1, Tekst.length());       //12. 
        Tekst = ""; Tekst = Tym;                                     //13. 
      } 
      cout << "."; 
    } else { cout << "BLAD -?Brak podanego tekstu!"; }               //14. 
  cout << "\n"; 
/* 
  Legenda: 
     1) Instrukcja warunkowa sprawdza, czy zmienna tekstowa "Tekst" 
        zawiera jakie� znaki. Je�eli posiada minimum jeden znak lub wi�cej, 
        to warunek jest spe�niony i nast�pi wykonanie instrukcji znajduj�cych 
        si� poni�ej (tj. za klamr� otwieraj�c� blok instrukcji "{"). 
        W innym przypadku zostanie wykonana instrukcja po s�owie ELSE 
        (tzn. zostanie wy�wietlony komunikat o braku podanego tekstu [komentarz nr 14]). 
     2) Dodanie na ko�cu podanego tekstu, separatora tekstu (separator tekstu 
        przechowywany jest w sta�ej znakowej "ZnakSeparatora"). 
     3) Wyzerowanie zmiennej liczbowej "TekstDl". 
        Przypisanie do zmiennej liczbowej "TekstDl" ilo�ci znak�w w podanym tek�cie. 
        Ilo�� znak�w jest wyliczana za pomoc� instrukcji LENGTH(). 
     4) Ilo�� powt�rze� p�tli FOR zale�y od ilo�ci znak�w w podanym tek�cie. 
        Ilo�� znak�w przechowywana jest w zmiennej liczbowej "TekstDl". 
     5) Wyzerowanie zmiennej liczbowej "NrPos". 
        Wyszukanie znaku separatora w podanym tek�cie dzi�ki funkcji FIND. 
        Nr indeksu wyszukanego znaku separatora przypisany zostanie do zmiennej liczbowej "NrPos". 
        Funkcja FIND(p1) - zwraca nr pozycji wyszukanego znaku. 
                           Szukany znak podaje si� w miejsce parametru P1. Parametr jest typu CHAR. 
     6) Warunek sprawdza, czy pobrany fragment tekstu faktycznie posiada jakie� znaki. 
        Je�eli tak, to wykonaj instrukcje znajduj�ce si� za klamr� otwieraj�c� (tj. "{"). 
        Funkcja SUBSTR s�u�y do wyci�gni�cia fragmentu tekstu z ca�ego podanego ci�gu znak�w. 
        Funkcja ta posiada 2 parametry. Parametr 1 okre�la pocz�tek fragmentu tekstu, 
        natomiast parametr 2 okre�la koniec pobieranego fragmentu tekstu. 
     7) Licznik++ = Licznik = Licznik+1 
        Zwi�kszenie zawarto�ci zmiennej liczbowej "Licznik" o warto�� 1. 
     8) Wy�wietlenie na ekranie przecinka (znajduje si� pomi�dzy cudzys�owami), je�eli 
        zawarto�� zmiennej liczbowej "I" b�dzie wi�ksza od warto�ci 0. 
     9) Znaki steruj�ce (tj. \n) powoduj� przej�cie o jedn� lini� w d�. 
        Wszystko co znajduje si� za znakami steruj�cymi (tj. \n) zostanie przeniesione 
        o jedn� lini� w d�. Znaki steruj�ce (tj. \n) umieszczane s� pomi�dzy cudzys�owami. 
    10) cout.width(3) - funkcja rezerwuje 3 znakowe miejsce na wy�wietlenie liczby lub tekstu. 
        Je�eli liczba lub tekst jest za kr�tka, to zostanie dope�niona znakami spacji 
        (tzw. znakami pustymi). Np. podana jest liczba "1" -> i otrzymamy "  2". 
    11) Wy�wietlenie na ekranie zawarto�ci zmiennej liczbowej "Licznik" 
        i pobranego fragmentu tekstu z podanego ci�gu znak�w. 
        Pocz�tek pobranego fragmentu tekstu rozpoczyna si� od nr indeksu 0, 
        a ko�czy si� na nr indeksu kt�ry przechowywany jest w zmiennej liczbowej "NrPos". 
    12) Wyczyszczenie zmiennej tekstowej "Tym". Przypisanie do zmiennej tekstowej "Tym" 
        pobranego fragmentu tekstu z podanego ci�gu znak�w. Pocz�tek pobranego fragmentu tekstu 
        rozpoczyna si� od nr przechowywanego w zmiennej liczbowej "NrPos+1", a ko�czy si� na 
        ostatnim znaku podanego ci�gu znak�w. 
    13) Wyczyszczenie zmiennej tekstowej "Tekst". Przypisanie do zmiennej tekstowej "Tekst" 
        zawarto�ci zmiennej tekstowej "Tym". 
    14) Wy�wietlenie komunikatu o braku podanego tekstu. 
*/ 
} 