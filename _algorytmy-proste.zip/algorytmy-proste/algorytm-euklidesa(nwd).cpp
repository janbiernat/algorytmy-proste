#include <iostream> 
#include <conio.h> 
using namespace std; 
/*--== Najwi�kszy wsp�lny dzielnik (NWD) ==-- 
  Implementacja (c)by Jan T. Biernat 
  = 
  Algorytm Euklidesa s�u�y do obliczania 
  NWD (najwi�kszego wsp�lnego dzielnika) 
  dw�ch liczb ca�kowitych. 
  - 
  Euklides z Aleksandrii �  matematyk grecki 
  przez wi�kszo�� �ycia dzia�aj�cy 
  w Aleksandrii (Egipt). 
  - 
  U�amek - wyra�enie lub liczba w postaci: 
    a 
    - 
    b 
  (czasami zapisujemy a/b), gdzie: 
  a - nazywamy licznikiem u�amka, 
  b - nazywamy mianownikiem u�amka. 
  Kresk� poziom� mi�dzy licznikiem i mianownikiem 
  nazywamy kresk� u�amkow�. 
  - 
  Skracanie u�amk�w zwyk�ych - przyk�ady: 
   1) 
      2   2 : 2   1 
      - = ----- = - = NWD to 2, (poniewa� 2/4 = 1/2 = 0.5) 
      4   4 : 2   2 
 
   2) 
      6   6 : 3   2 
      - = ----- = - = NWD to 3, (poniewa� 6/9 = 2/3 = 0.66) 
      9   9 : 3   3 
 
   3) 
       8    8 : 8   1 
      -- = ------ = - = NWD to 8, (poniewa� 8/16 = 1/2 = 0.5) 
      16   16 : 8   2 
 
   4) 
      21   21 : 7   3 
      -- = ------ = - = NWD to 7, (poniewa� 21/14 = 3/2 = 1.5) 
      14   14 : 7   2 
 
   5) 
      28   28 : 2   14 
      -- = ------ = -- = NWD to 2, (poniewa� 28/22 = 14/11 = 1.27) 
      22   22 : 2   11 
 
   6) NWD liczb 10 i 6 jest liczba 2. 
   7) NWD liczb 75 i 100 jest liczba 25. 
   8) NWD liczb 15 i 5 jest liczba 5. 
*/ 
//Blok g��wny(startowy). 
int main() { 
  cout << "--== Najwiekszy wspolny dzielnik (NWD) ==--\n"; 
  cout << "Implementacja (c)by Jan T. Biernat\n\n"; 
  //Deklaracja zmiennych. 
    int A = 0, B = 0; 
  //Wykonaj zadanie. 
    cout << "A: "; cin >> A; 
    cout << "B: "; cin >> B; 
    while(A != B) { 
      if(A > B) { A = A - B; } 
      else { B = B - A; } 
    } 
    cout << "NWD = " << A << "\n"; 
  //Czekaj, a� u�ytkownik naci�nie dowolny klawisz. 
    cout << "\n\nNacisnij dowolny klawisz ..."; getch(); 
} 