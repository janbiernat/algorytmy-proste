#include <iostream> //Obs�uga strumieni (np. przesy�anie danych na ekran). 
#include <conio.h>  //Obs�uga klawiatury. 
#include <math.h>   //Biblioteka z funkcjami matematycznymi. 
#include <cstdlib>  //Posiada instrukcje do zainicjowania generatora liczb pseudolosowych. 
#include <ctime>    //Biblioteka "ctime " zawiera funkcje zwi�zane z obs�ug� czasu i daty. 
using namespace std; 
/*--== Algorytm - Szablon ==-- 

*/ 
int main() { 
  cout << "--== Algorytm - Szablon ==--\n"; 

} 