#include <iostream> 
#include <conio.h> 
#include <fstream> //Posiada funkcje zwi�zane z obs�ug� plik�w. 
using namespace std; 
/*--== Liczba binarna(dw�jkowa) - czy liczba parzysta ==-- 
 Copyright (c)by Jan T. Biernat 
 = 
 Napisz program, kt�ry wy�wietli nr linii zawieraj�cej 
 liczb� parzyst� w zapisie binarnym. 
 Liczby w zapisie binarnym znajduj� si� w pliku tekstowym 
 o nazwie "bin-liczby.txt". 
*/ 
int main() { 
  cout << "--== Liczba binarna(dwojkowa) - czy liczba parzysta ==--\n"; 
  cout << "Copyright (c)by Jan T. Biernat\n\n\n"; 
  //Deklaracja zmiennych. 
    string Linia = ""; 
    long int Licznik = 0; 
  //Sprawdza wszystkie liczby znajduj�ce si� w pliku tekstowym. 
    fstream PlikDane("bin-liczby.txt", ios::in); //1 
    if(PlikDane != NULL) { //2 
      Linia = ""; 
      cout << "Liczba parzysta jest w linii nr:"; 
      while(getline(PlikDane, Linia)) { //3 
        Licznik++; 
        if(Linia[Linia.length()-1] == '0') { cout << " " << Licznik; } 
      } 
    } else { cout << "BLAD -?Brak pliku o podanej nazwie na dysku!\n"; } 
    PlikDane.close(); 
  //Czekaj, a� u�ytkownik naci�nie klawisz ENTER. 
    cout << "\n\nNacisnij klawisz ENTER..."; getch(); 
/* 
  Legenda: 
  1) Utworzenie obiektu o nazwie "PlikDane" na podstawie klasy "fstream". 
     Od tego momentu mo�na u�ywa� instrukcji, kt�re nale�� do klasy "fstream". 
     Otwarcie pliku do odczytu (tj. ios::in). 
  2) Je�eli warunek jest spe�niony, czyli obiekt "PlikDane" przechowuje 
     warto�� r�n� od NULL, to plik istnieje fizycznie na dysku. 
     Gdy plik istnieje fizycznie na dysku, to nast�pi jego odczyt linia po linii. 
  3) Odczytanie kolejnej linii. Odczyt b�dzie kontynuowany, do momentu 
     napotkania ko�ca pliku. Odczytana z pliku tekstowego linia b�dzie przypisana 
     do zmiennej tekstowej "Linia". 
*/ 
} 