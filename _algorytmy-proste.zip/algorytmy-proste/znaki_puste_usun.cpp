#include <iostream> 
using namespace std; 
/*--== Usuwaj nadmiarowe znaki puste (czyli znaki spacji) ==-- 
  Copyright (c)by Jan T. Biernat 
  = 
  Napisz program w kt�rym za pomoc� funkcji 
  zostan� usuni�te nadmiarowe spacje. 
  Przyk�ad: 
       Podany jest ci�g znak�w: 
       "          Komputer          jest        przydatny          w     �yciu    cz�owieka    ". 
 
       Wynikiem dzia�ania funkcji ma by� zwr�cony ci�g znak�w: 
       "Komputer jest przydatny w �yciu cz�owieka". 
*/ 
string znaki_puste_usun(string Str = "") { 
  //znaki_puste_usun - Funkcja usuwa nadmiarowe znaki puste (czy znaki spacji). 
  string Tekst = ""; 
  int Tak = 0; 
  if(Str != "") { 
    for(int I = 0; I < Str.length(); I++) { 
      if(Str[I] != ' ') { Tekst += Str[I]; Tak = 0; } 
      else { 
             if(Tak == 0) { Tekst += ' '; Tak++; } 
           } 
    } 
    Str = ""; 
    if(Tekst[0] == ' ') { Str = Tekst.substr(1, Tekst.length()); } 
    else { Str = Tekst; } 
    if(Str[Str.length()-1] == ' ') { return Str.substr(0, Str.length()-1); } 
    else { return Str; } 
  } else { return "\n-?Brak podanego tekstu!"; } 
} 
//Blok g��wny(startowy). 
int main() { 
  cout << "--== Usuwaj nadmiarowe znaki puste (czyli znaki spacji) ==--\n"; 
  cout << "Copyright (c)by Jan T. Biernat\n\n"; 
  string Tekst = ""; 
  cout << "Podaj tekst: "; getline(cin, Tekst); 
  cout << "\nPodany tekst to: \"" << Tekst << "\"."; 
  cout << "\nTekst bez nadmiarowych spacji: \"" << znaki_puste_usun(Tekst) << "\".\n\n"; 
} 