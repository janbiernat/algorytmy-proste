#include <iostream> 
#include <conio.h> 
using namespace std; 
string Dec2Bin(long int Liczba = 0) { 
  //Dec2Bin - Konwersja liczby dziesi�tnej na liczb� dw�jkow�. 
  long int Wynik = 0, Licznik = 0; //Deklaracja zmiennych. 
  string Tablica = "", Rezultat = ""; 
  //Wykonaj konwersj� liczby dziesi�tnej na liczb� dw�jkow�. 
    if(Liczba > 0) { 
      do{ 
          Wynik = 0; 
          Wynik = Liczba/2; 
          if(Liczba % 2 != 0) { Tablica = Tablica+"1"; } 
          else { Tablica = Tablica+"0"; } //Dodaj do przechowywanych 
                                          //element�w tablicy tekstowej, 
                                          //kolejny element. 
          Liczba = 0; Liczba = Wynik; 
          Licznik++; 
      } while(Wynik != 0); 
      //Wy�wietl wynik pobieraj�c liczby z tablicy od ty�u. 
        Rezultat = ""; 
        for(int I = Licznik-1; I >-1; I--) { 
          Rezultat = Rezultat+Tablica[I]; 
        } 
      return Rezultat; 
    } else { return 0; } 
} 
//Blok g��wny/startowy. 
int main() { 
  cout <<"--== Dec2Bin wer2 ==--\n"; 
  cout <<"Copyright (c)by Jan T. Biernat\n"; 
  cout <<"Systemy liczbowe: Dziesietny -> Dwojkowy.\n\n"; 
  //Deklaracja zmiennych. 
    long int Liczba = 0; 
  //Pobranie liczby od u�ytkownika. 
    cout << "Podaj liczbe dziesietna: "; 
    cin >> Liczba; 
  //Przeliczenie liczby 10 na liczb� 2. 
    cout << "\n" << Liczba << " = "; 
    cout << Dec2Bin(Liczba); //Wywo�anie funkcji "Dec2Bin". 
  //Czekaj, a� u�ytkownik naci�nie klawisz ENTER. 
    cout << "\n\nNacisnij klawisz ENTER..."; 
    getch(); 
} 