#include <iostream> 
#include <conio.h> 
#include <cstdlib> //1. 
using namespace std; 
/*--== Menu w konsoli ==-- 
  Copyright (c)by Jan T. Biernat*/ 
int main() { 
  //Deklaracja sta�ych. 
    const short int MenuIlosc = 5; 
    const string MenuZnakiPuste = "     "; 
  //Deklaracja zmiennych. 
    short int MenuWybrano = 0; 
    int KodKlaw; 
    string Opcja[MenuIlosc]; 
  //Menu - Obs�uga. 
    do { 
      system("cls"); //2. 
      cout << "--== Menu ==--\n"; 
      cout << "Copyright (c)by Jan T. Biernat\n\n"; 
      Opcja[0] = "Atari"; 
      Opcja[1] = "Amstrad"; 
      Opcja[2] = "ZX Spectrum"; 
      Opcja[3] = "Commodore"; 
      Opcja[4] = "Cry"; 
      for(int I = 0; I < MenuIlosc; I++) { 
        cout << "\n"; 
        if(MenuWybrano == I) { cout << "  -->"; } 
        else { cout << MenuZnakiPuste; } 
        cout << Opcja[I]; 
      } 
      cout << "\n" << MenuZnakiPuste << "Wybrano: "; 
      KodKlaw = 0; 
      KodKlaw = getch(); //3. 
      if((KodKlaw == 0) || (KodKlaw == 224)) { //4. 
        KodKlaw = 0; 
        KodKlaw = getch()+224; //5. 
      } 
      if(KodKlaw == 13) { 
        //Klawisz ENTER. 
        cout << MenuWybrano << " " << Opcja[MenuWybrano]; 
      } else { 
               if(KodKlaw == 296) { 
                 //Strza�ka w g�r�. 
                   MenuWybrano--; 
                   if(MenuWybrano < 0) { MenuWybrano = 0; } 
               } else if(KodKlaw == 304) { 
                        //Strza�ka w d�. 
                          MenuWybrano++; 
                          if(MenuWybrano > MenuIlosc-1) { MenuWybrano = MenuIlosc-1; } 
                      } 
             } 
    } while(KodKlaw != 27); //6. 
/* 
  Legenda: 
  1) Pod��czenie biblioteki "cstdlib", kt�ra posiada m.in. funkcje: 
     * konwersji ci�gu znak�w na liczb� i odwrotnie, 
     * losuj�ce liczb� z podanego zakresu, 
     * do wywo�ywania polece� systemowych. 
  2) Wywo�anie polecenia systemowego CLS w konsoli (tj. wierszu plecenia). 
  3) Pobranie kodu znaku za pomoc� instrukcji "getch()" i przypisanie go do zmiennej liczbowej "KodKlaw". 
     Je�eli zostan� naci�ni�te klawisze strza�ki lub inne klawisze funkcyjne to instrukcja "getch()" zwr�ci kod 224 lub 0, 
     a dopiero p�niej kod klawisza. 
     To znaczy dla strza�ki: 
      * w g�r� kod 72, 
      * w d� kod 80, 
      * w lewo kod 75, 
      * w prawo kod 77. 
     Funkcja "getch()" zwraca kod 224 lub 0 w kompilatorach MinGW (Falcon C++) i Visual C++. 
     W innych kompilatorach kody te mog� by� inne, poniewa� nie ma okre�lonego standardu. 
  4) Sprawdzenie, czy zosta� naci�ni�ty klawisz funkcyjny, je�eli tak, to odczytaj ponownie 
     kod klawisza z dodan� warto�ci� 224 (nr 5). 
  5) Odczytaj ponownie kod klawisza z dodan� warto�ci� 224 i przypisz kod znaku do zmiennej liczbowej "KodKlaw". 
  6) P�tla DO ... WHILE jest tak d�ugo wykonywana, a� u�ytkownik naci�nie klawisz ESC. 
*/ 
} 