#include <iostream> 
#include <conio.h> 
using namespace std; 
int main() { 
  cout << "--== Kod klawisza ==--\n\n"; 
  cout << "UWAGA: Klawisz ESC wychodzi z programu.\n\n"; 
  int KodKlaw = 0;                                              //1. 
  do { 
    KodKlaw = 0;                                                //2. 
    KodKlaw = getch();                                          //3. 
    if((KodKlaw == 0) || (KodKlaw == 224)) {                    //4. 
      KodKlaw = 0;                                              //5. 
      KodKlaw = getch()+224;                                    //6. 
    } 
    cout << "\nKod: " << KodKlaw << " znak: " << (char)KodKlaw; //7. 
  } while(KodKlaw != 27);                                       //8. 
/* 
  Legenda: 
  1) Deklaracja zmiennej liczbowej ca�kowitej "KodKlaw" z r�wnoczesnym przypisaniem warto�ci pocz�tkowej 0. 
  2) Wyzerowanie zmiennej liczbowej "KodKlaw". 
  3) Pobranie kodu znaku za pomoc� instrukcji "getch()" i przypisanie go do zmiennej liczbowej "KodKlaw". 
     Je�eli zostan� naci�ni�te klawisze strza�ki lub inne klawisze funkcyjne to instrukcja "getch()" zwr�ci kod 224 lub 0, 
     a dopiero p�niej kod klawisza. 
     To znaczy dla strza�ki: 
      * w g�r� kod 72, 
      * w d� kod 80, 
      * w lewo kod 75, 
      * w prawo kod 77. 
     Funkcja "getch()" zwraca kod 224 lub 0 w kompilatorach MinGW (Falcon C++) i Visual C++. 
     W innych kompilatorach kody te mog� by� inne, poniewa� nie ma okre�lonego standardu. 
  4. Sprawdzenie, czy zosta� naci�ni�ty klawisz funkcyjny, je�eli tak, to odczytaj ponownie 
     kod klawisza z dodan� warto�ci� 224 (nr 6). 
  5. Wyzerowanie zmiennej liczbowej "KodKlaw". 
  6. Odczytaj ponownie kod klawisza z dodan� warto�ci� 224 i przypisz kod znaku do zmiennej liczbowej "KodKlaw". 
  7. Wy�wietl na ekranie nast�puj�ce dane: 
      * tekst znajduj�cy si� pomi�dzy cudzys�owami, 
      * kod znaku (kod przechowywany jest w zmiennej liczbowej "KodKlaw"), 
      * kod znaku, kt�ry rzutowany jest na typ CHAR (co umo�liwia wy�wietlenie znaku o podanym kodzie). 
  8. P�tla DO ... WHILE jest tak d�ugo wykonywana, a� u�ytkownik naci�nie klawisz ESC. 
 */ 
} 