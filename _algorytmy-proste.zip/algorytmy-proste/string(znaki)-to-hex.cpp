#include <iostream> //Biblioteka do obs�uga strumieni (np. klawiatura i monitor). 
#include <conio.h> //Biblioteka do obs�ugi klawiatury. 
#include <fstream> //Biblioteka do obs�ugi plik�w. 
#include <cstdlib> //Biblioteka posiada m.in. funkcj� do losowania i konwertowania liczb. 
using namespace std; 
/*--== String (Znaki) na HEX ==-- 
  Copyright (c)by Jan T. Biernat 
  = 
  Napisz program, kt�ry b�dzie wczytywa� zawarto�� 
  plik�w tekstowych. Odczytane dane ma konwertowa� 
  na posta� szesnastkow� (HEX) i wypisa� na ekranie 
  w formacie: znaki szesnastkowe | odczytane znaki. 
  Po ka�dym znaku ma by� wstawiony znak spacji. 
  Na przyk�ad: "41 74 61 72 69 2c | A t a r i ,". 
*/ 
void string_to_hex(string Str = "") { 
  //string_to_hex - Funkcja zamienia podane znaki na ich odpowiedniki w systemie szesnastkowym (HEX). 
    if(Str != "") { 
      char Znak[Str.length()]; //Zadeklarowanie zmiennej znakowej "Znak" o d�ugo�ci podanego ci�gu znak�w. 
      for(int I = 0; I < Str.length(); I++) { 
        cout << itoa(int(Str[I]), Znak, 16) << " "; 
      } 
    } else { cout << "?"; } 
} 
void Literowanie(string Str = "") { 
  //Literowanie - Funkcja wy�wietla podany ci�g znak�w, robi�c znak spacji po ka�dym znaku. 
    if(Str != "") { 
      for(int I = 0; I < Str.length(); I++) { cout << Str[I] << " "; } 
    } else { cout << "?"; } 
} 
//Blog g��wny/startowy. 
int main() { 
  cout << "--== String (Znaki) na HEX ==--\n"; 
  cout << "Copyright (c)by Jan T. Biernat\n\n"; 
  //Deklaracja sta�ych. 
    const int MaksIloscZnakow = 23; 
  //Deklaracja zmiennych. 
    string Linia = "", Znaki20 = ""; 
  //Konwersja znak�w na ich odpowiedniki szesnastkowe (HEX). 
    fstream PlikDane("str-to-hex.txt", ios::in); //1. 
    if(PlikDane != NULL) { 
      Linia = ""; 
      while(getline(PlikDane, Linia)) { 
        Znaki20 = ""; Znaki20 = Linia.substr(0, MaksIloscZnakow); 
        cout << "\n"; 
        string_to_hex(Znaki20); 
        for(int I = 0; I < (MaksIloscZnakow*3)-(Znaki20.length()*3); I ++) { cout << " "; } //Dope�nienie znakami pustymi. 
        cout<<" | "; 
        Literowanie(Znaki20); 
      } 
    } else { cout << "BLAD -?Brak pliku o podanej nazwie na dysku!\n"; } 
    PlikDane.close(); 
    cout << "\n\nNacisnij dowolny klawisz..."; 
    getch(); 
 /* 
   Legenda: 
   1: Utworzenie obiektu o nazwie "PlikDane" na podstawie klasy "fstream". 
      Od tego momentu mo�na u�ywa� instrukcji, kt�re nale�� do klasy "fstream". 
      Otwarcie pliku do odczytu (tj. ios::in). 
*/ 
} 