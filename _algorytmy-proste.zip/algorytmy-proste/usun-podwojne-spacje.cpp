#include <iostream> 
#include <conio.h> 
/*--== Usu� podw�jne spacje ==-- 
  Copyright (c)by Jan T. Biernat 
  = 
  Tre�� zadania: 
  Napisz program, kt�ry z podanego 
  �a�cucha znak�w usunie powtarzaj�ce 
  si� spacje wyst�puj�ce obok siebie.*/ 
using namespace std; 
string UsunPodwojneSpacje(string Str = "") { 
  //UsunPodwojneSpacje - Funkcja usuwa podw�jne spacje wyst�puj�ce obok siebie w podanym ci�gu znak�w. 
    string Tekst = ""; 
    short int Tak = 0; 
    if(Str != "") { 
      for(int I = 0; I < Str.length(); I++) { 
        if(Str[I] != ' ') { Tekst = Tekst+Str[I]; Tak = 0; } 
        else { 
               if(Tak == 0 ) { Tekst+= ' '; Tak++; } 
             } 
      } 
      return Tekst; 
    } else { return ""; } 
} 
//Blok g��wny/startowy. 
int main() { 
  cout <<"--== Usun podwojne spacje ==--\n"; 
  cout <<"Copyright (c)by Jan T. Biernat\n\n"; 
  //Deklaracja zmiennych. 
    string Tekst = ""; 
  //Pobierz dane z klawiatury. 
    cout << "Podaj tekst: "; 
    getline(cin, Tekst); 
    cout << "\"" << Tekst << "\"\n= \"" << UsunPodwojneSpacje(Tekst) << "\"."; 
  //Naci�nij dowolny klawisz. 
    cout << "\n\nNacisnij dowolny klawisz..."; 
    getch(); 
} 