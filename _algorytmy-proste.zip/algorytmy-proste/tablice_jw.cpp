#include <iostream> 
#include <conio.h> 
#include <cstdlib> /*Posiada instrukcje do zainicjowania 
                     generatora liczb pseudolosowych.*/ 
#include <ctime> /*Biblioteka "ctime " zawiera funkcje 
                   zwi�zane z obs�ug� czasu i daty.*/ 
/*--== Tablice jednowymiarowe ==-- 
  Copyright(c)by Jan T. Biernat*/ 
using namespace std; 
void TablicaJW_Pokaz(int Tablica[], int IloscElementow=0) { 
  //TablicaJW_Pokaz - Wy�wietl zawarto�� tablicy podanej w 1 parametrze. 
    if(IloscElementow > 0) { 
      cout << "["; 
      for(int I=0; I < IloscElementow; I++) { 
        if(I > 0) { cout << ", "; } 
        cout << Tablica[I]; 
      } 
      cout << "]"; 
    } else { cout << "BLAD -?"; } 
} 
//Blok g��wny/startowy. 
int main() { 
  cout <<"--== Tablice jednowymiarowe ==--\n"; 
  cout <<"Copyright(c)by Jan T. Biernat\n\n"; 
  //Deklaracja sta�ych. 
    const int IloscElementow = 9; 
    const int Zakres = 39; 
  //Deklaracja zmiennych. 
    int Tablica[IloscElementow]; 
  //Wprowad� dane do tablicy. 
    srand(time(NULL)); //Zainicjowanie generatora liczb pseudolosowych. 
    for(int I=0; I < IloscElementow; I++) { 
      Tablica[I] = 0; 
      Tablica[I] = rand()%Zakres; 
    } 
  //Wy�wietl zawarto�� tablicy. 
    cout << "\nZawartosc wylosowanej tablicy:"; 
    cout << "\n["; 
    for(int I=0; I < IloscElementow; I++) { 
      if(I > 0) { cout << ", "; } 
      cout << Tablica[I]; 
    } 
    cout << "]"; 
  //Wy�wietl zawarto�� tablicy za pomoc� funkcji "TablicaJW_Pokaz()". 
    cout << "\n"; 
    TablicaJW_Pokaz(Tablica, IloscElementow); 
  //Naci�nij dowolny klawisz. 
    cout << "\n\nNacisnij dowolny klawisz..."; 
    getch(); 
} 