#include <iostream> 
using namespace std; 
string WyrWielLit(string Str = "") { 
  //WyrWielLit - Ka�dy wyraz pisz Wielk� Liter�. 
  string T = ""; 
  if(Str != "") { 
    Str = ' '+Str; 
    for(int I = 0; I < Str.length(); I++) { 
      if((Str[I-1] == ' ') && (Str[I] != ' ')) { 
        if(((int)Str[I] > 96) && ((int)Str[I] < 123)) { T = T+char((int)Str[I]-32); } 
        else { T += Str[I]; } 
      } else { 
               if(((int)Str[I] > 64) && ((int)Str[I] < 91)) { T = T+char((int)Str[I]+32); } 
               else { T += Str[I]; } 
             } 
    } 
    return T.substr(1, T.length()); 
  } else { return "?"; } 
} 
//Blok g��wny (startowy). 
int main() { 
  cout << "--== Kazdy wyraz pisz Wielk� Liter� ==--\n"; 
  cout << "Copyright (c)by Jan T. Biernat\n"; 
  cout << "\n\n"; 
  string T = ""; 
  cout << "Podaj dowolny tekst: "; getline(cin, T); 
  cout << "Podany tekst to  : \"" << T << "\".\n"; 
  cout << "Tekst po zamianie: \"" << WyrWielLit(T) << "\"."; 
  cout << "\n\n"; 
} 