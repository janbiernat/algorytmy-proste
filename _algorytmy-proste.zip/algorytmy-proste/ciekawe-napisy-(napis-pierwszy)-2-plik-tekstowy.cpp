#include <iostream> 
#include <conio.h> 
#include <math.h> 
#include <fstream> 
using namespace std; 
/*--== Ciekawe napisy 2 - Plik tekstowy (napis pierwszy) ==-- 
                                                 Konsola 
  Copyright (c)by Jan T. Biernat 
  = 
  Napis pierwszy to taki napis, w kt�rym 
  suma kod�w ASCII jest liczb� pierwsz�. 
  Przyk�adowo: 
    Suma kod�w ASCII w napisie BALAST 
    wynosi 439 i jest liczb� pierwsz�, 
    co oznacza, �e napis BALAST jest 
    napisem pierwszym. 
  Przyk�adowe napisy pierwsze: 
    balast, pralnia, rzeka, katalog, 
    komputer, procesor, system, dysk. 
  = 
  UWAGA: Wielko�� liter ma znaczenie. 
         Podane wyrazy jako przyk�ady, to wyrazy 
         pierwsze pod warunkiem �e s� pisane 
         ma�y literami. 
  = 
  Napisz program kt�ry sprawdzi wszystkie napisy 
  pobrane z pliku tekstowego i wy�wietli tylko te 
  napisy, kt�re s� napisami pierwszymi. 
*/ 
short int CzyLiczbaPierwsza(int Liczba = 0) { 
  short int CzyNie = 0; 
  if(Liczba < 2) { Liczba = 2; cout << "Wartosc domyslna 2."; } 
  for(int L = 2; L <= sqrt(Liczba); L++) { 
    if(Liczba % L == 0) { CzyNie = 1; break; } 
  } 
  return CzyNie; 
} 
//Blok g��wny/startowy. 
int main() { 
  cout << "--== Ciekawe napisy 2 - Plik tekstowy (napis pierwszy) ==--\n"; 
  cout << "                                               Konsola\n"; 
  cout << "Copyright (c)by Jan T. Biernat\n\n\n"; 
  //Deklaracja zmiennych. 
    string Linia = ""; 
    int SumaKodZnaku = 0; 
    long int Licznik = 0; 
  //Pobranie danych z pliku tekstowego. 
    fstream PlikDane("napisy.txt", ios::in); 
    if(PlikDane != NULL) { 
      Linia = ""; 
      while(getline(PlikDane, Linia)) { 
        SumaKodZnaku = 0; 
        for(int I = 0; I < Linia.length(); I++) { 
          SumaKodZnaku += (int)Linia[I]; 
        } 
          if(CzyLiczbaPierwsza(SumaKodZnaku) == 0) { 
            Licznik++; 
            if(Licznik == 1) { cout << "\nLista napisow pierwszych:\n"; } 
            cout << "\n"; cout.width(9); cout.fill(' '); 
            cout << Licznik << ": \"" << Linia << "\"."; 
          } 
      } 
      Linia = ""; 
    } else { cout << "BLAD -?Brak pliku o podanej nazwie na dysku!\n"; } 
    PlikDane.close(); 
  //Zatrzymaj program do czasu naci�ni�cia dowolnego klawisza. 
    cout << "\n\n\nNacisnij dowolny klawisz ..."; getch(); 
} 