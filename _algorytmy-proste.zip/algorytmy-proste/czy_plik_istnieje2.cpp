#include <iostream> 
#include <conio.h> 
#include <fstream> //Posiada funkcje zwi�zane z obs�ug� plik�w. 
/*--== Czy plik istnieje ==-- 
  Copyright (c)by Jan T. Biernat*/ 
using namespace std; 
int iPlikIstnieje(string NazwaPliku) { 
  //iPlikIstnieje - Sprawdza, czy plik fizycznie znajduje si� na dysku. 
    fstream PlikOtworz(NazwaPliku.c_str(), ios::in); //1 
    PlikOtworz.close(); //2 
    if(PlikOtworz == NULL) { return 0; } //3 
    else { return 1; } 
/* 
  Legenda: 
    1) Utworzenie obiektu o nazwie "PlikOtworz" na podstawie klasy "fstream". 
       Od tego momentu mo�na u�ywa� instrukcji, kt�re nale�� do klasy "fstream". 
       c_str() - Instrukcja wykonuje konwersj� tekstu na tablic� znak�w. 
                 Taki zapis umo�liwia przekazanie tekstu jako parametru funkcji 
                 w postaci char* lub const char* (w standardzie j�zyka C). 
      Parametr 2 (tj. ios::in) ustawia tryb tylko do odczytu (tzn. plik 
                               b�dzie mo�na tylko odczyta�). Nie b�dzie mo�liwe 
                               manipulowanie plikiem (tzn. usuwanie lub modyfikowanie). 
                               Do sprawdzenia, czy plik istnieje tryb do odczytu jest 
                               wystarczaj�cy. 
    2) Zamkni�cie pliku  za pomoc� instrukcji "close", kt�ry zosta� otwarty do odczytu. 
    3) Je�eli warunek jest spe�niony, czyli obiekt "PlikOtworz" przechowuje 
       warto�� NULL, to funkcja "iPlikIstnieje" zwr�ci warto�� 0. 
       W innym przypadku funkcja "iPlikIstnieje" zwr�ci warto�� 1 (patrz: kod po instrukcji ELSE). 
*/ 
} //iPlikIstnieje. 
//Blok g��wny/startowy. 
int main() { 
  cout << "--== Czy plik istnieje ==--\n"; 
  cout << "Copyright (c)by Jan T. Biernat\n\n"; 
  //Deklaracja zmiennych. 
    string NazwaPliku = ""; 
    short int PlikJest = 0; 
  //Pobranie nazwy pliku od u�ytkownika. 
    cout << "Podaj nazwe pliku: "; 
    getline(cin, NazwaPliku); //Pobiera ca�� lini� i wpisuje do zmiennej tekstowej "NazwaPliku" wprowadzone dane. 
  //Sprawd�, czy plik o podanej nazwie istnieje. 
    cout << "\"" << NazwaPliku << "\" = "; 
    PlikJest = iPlikIstnieje(NazwaPliku); //Wywo�anie funkcji sprawdzaj�cej, czy plik znajduje si� na dysku. 
    if(PlikJest > 0) { cout << "Plik znajduje sie fizycznie na dysku."; } 
    else { cout << "BLAD -?Plik o podanej nazwie nie istnieje!"; } 
  //Naci�nij dowolny klawisz. 
    cout << "\n\nNacisnij dowolny klawisz..."; 
    getch(); 
} 