#include <iostream> 
#include <conio.h> 
using namespace std; 
/* 
  --== Mo�enie po rosyjsku ==-- 
  Copyright (c)by Jan T. Biernat 
  = 
  Algorytm: 
  Krok 1 - Zapisz obok siebie 2 liczby, kt�re chcesz pomno�y� (np. 120 i 47 lub 5 i 10). 
  Krok 2 - W 1 kolumnie w kolejnych wierszach podwajaj zapisan� liczb�. 
           Natomiast w drugiej kolumnie w kolejnych wierszach dziel liczb� 
           ca�kowit� przez 2 i odrzucaj reszt� (np. 5/2 = 2.5, to odrzucaj reszt� tj. 0.5). 
  Krok 3 - Kontynuuj dzia�anie do momentu, a� w drugiej kolumnie osi�gniesz 1. 
  Krok 4 - Je�eli liczba w drugiej kolumnie jest parzysta, to wykre�l ca�y wiersz. 
  Krok 5 - Podsumuj (dodaj) wszystkie liczby z pierwszej kolumny. To jest wynik z mno�enia. 
  Na przyk�ad: 
    120 | 47 
    240 | 23 
    480 | 11 
    960 |  5 
   1920 |  2 <- ten wiersz ca�y usuwamy. 
   3840 |  1 
 Sumujemy liczby: 120+240+480+960+3840 = 5640. 
*/ 
int main() { 
  cout << "--== Mozenie po rosyjsku ==--\n"; 
  cout << "Copyright (c)by Jan T. Biernat\n\n"; 
  //Deklaracja zmiennych. 
    int A = 0, B = 0, Suma = 0; 
  //Wy�wietlenie pytania i pobranie danych z klawiatury. 
    cout << "A = "; cin >> A; 
    cout << "B = "; cin >> B; 
  //Wy�wietlenie wyniku z mno�enia dw�ch liczb wykonanego tradycyjn� metod�. 
    cout << A << " * " << B << " = " << (A*B); 
  //Algorytm: Mno�enie po rosyjsku. 
    cout << "\n"; 
    for(int I = 0; B > 0; I++) { 
      if(B % 2 != 0) { Suma+= A; } 
      cout << "\n"; 
      cout.width(7); cout << A << " | "; 
      cout.width(7); cout << B; 
      A = 2 * A; 
      B = B / 2; 
    } 
    cout << "\n\nSuma = " << Suma; 
  //Czekaj, a� u�ytkownik naci�nie klawisz ENTER. 
    cout << "\n\n\nNacisnij klawisz ENTER..."; 
    getch(); 
} 