#include <iostream>
#include <conio.h>
#include <cstdlib> 
#include <ctime> 
#include <fstream>
/*--== Gra w Pa�stwa, Miasta: �ci�ga ==--
  Copyright (c)by Jan T. Biernat
  =
  Napisz program, kt�ry b�dzie pomaga�
  przy grze Pa�stwa, Miasta.
  Za�o�enia dla baz z danymi do programu:
  1. Dane musz� by� umieszczone w plikach tekstowych,
     kt�re znajduj� si� w tym samym katalogu co plik (program) "gra_pm.exe".
  2. Ka�da kategoria posiada pliki tekstowe, dla poszczeg�lnych liter alfabetu.
     Na przyk�ad: kategoria MIASTA.
                  Tworzymy plik tekstowy dla miast rozpoczynaj�cych si�
                  od litery A. Tak samo dla miast rozpoczynaj�cych si�
                  od litery B. Dla kolejnych miast robimy podobnie.
     Dla kolejnych kategorii robimy tak samo.
  3. Nazwa pliku z danymi sk�ada si� z trzech element�w:
     3.1. Litery alfabetu podanej przez u�ytkownika.
     3.2. Nazwy pobranej z pliku konfiguracyjnego (tj. "gra_pm.cfg").
          Nazwa pliku tekstowego znajduje si� w pliku konfiguracyjnym
          za znakiem �rednika (tj. ";").
     3.3. Kropki i rozszerzenia trzyliterowego (tj. ".txt").
*/
using namespace std;
string TekstWyrownaj(string Str = "", int Dl = 0) {
  string Rezultat = "";
  Rezultat+= Str;
  if((Str != "") && (Dl > Str.length())) {
    for(int I = 0; I < Dl-Str.length(); I++) {
      Rezultat+= " ";
    }
  }
  Rezultat+= ": ";
  return Rezultat;
}
//
string WierszPobierzLos(string PlikNazwa = "") {
  const int Ilosc = 300;
  //
  //Deklaracja zmiennych.
    string Dane[Ilosc];
    string Linia = "", Rezultat = "";
    long Licznik = 0;
  //
  //Odczyt pliku tekstowego.
    fstream PlikDane(PlikNazwa.c_str(), ios::in);
    if(PlikDane != NULL) {
      Linia = "";
      while(getline(PlikDane, Linia)) {
        Dane[Licznik] = Linia; Licznik++;
      }
      Dane[Licznik] = "<k>";
      //
      //Losowanie wiersza.
        srand(time(NULL));
        if(Linia != "") { Rezultat = Dane[rand()%Licznik]+"."; }
        else { Rezultat = "Plik jest pusty!"; }
    } else { Rezultat = "BLAD -?Brak pliku!"; }
    PlikDane.close();
    return Rezultat;
}
//
//Blok g��wny.
int main() {
  cout << "--== Gra w Panstwa, Miasta: Sciaga ==--\n";
  cout << "Copyright (c)by Jan T. Biernat\n\n\n";
  //
  //Deklaracja zmiennych.
    string Linia = "";
    int ZnakPoz = 0;
    string Litera = "";
    string PlikNazwa[2];
  //
  //Podaj liter�.
    cout << "Litera (a-z): ";
    getline(cin, Litera);
  //
  //Wczytanie pliku konfiguracyjnego.
    if(Litera != "") {
      if((int(Litera[0]) > 64) && (int(Litera[0]) < 91)) {
        Litera[0] = char(int(Litera[0])+32); //Zamie� DU�� LITER� na ma�� liter� (np. A -> a).
      }
      cout << "Podana litera to \"" << Litera[0] << "\".\n";
      fstream PlikDane("gra_pm.cfg", ios::in);
      if(PlikDane != NULL) {
        Linia = "";
        while(getline(PlikDane, Linia)) {
          ZnakPoz = 0;
          for(ZnakPoz = 0; ZnakPoz < Linia.length(); ZnakPoz++){
           if(Linia[ZnakPoz] == ';') { break; }
          }
          PlikNazwa[0] = ""; PlikNazwa[0] = Linia.substr(0, ZnakPoz);
          PlikNazwa[1] = ""; PlikNazwa[1] = Litera[0]+Linia.substr(ZnakPoz+1, Linia.length())+".txt";
          cout << "\n" << TekstWyrownaj(PlikNazwa[0], 8) << WierszPobierzLos(PlikNazwa[1]);
        }
      } else { cout << "BLAD -?Brak pliku o podanej nazwie na dysku!\n"; }
      PlikDane.close();
  } else { cout << "BLAD -?Brak podanej litery!"; }
  //
  //Naci�nij dowolny klawisz.
    cout << "\n\nNacisnij dowolny klawisz ...";
    getch();
cout << "\n\n";
}